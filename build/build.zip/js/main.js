(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
"use strict";
//Плохой фактор
var BadFactor = (function () {
    function BadFactor(description) {
        this._description = description;
        this._hitPoints = description.hitPoints;
    }
    //Проверка, может ли данный фактор влиять на определённый ресурс. Делегируется свойствам ресурса
    BadFactor.prototype.canAffectTo = function (resource) {
        return this._description.canAffectTo(resource);
    };
    //Повлиять на ресурс. Делегируется свойствам ресурса
    BadFactor.prototype.affect = function (resource) {
        this._description.affect(resource);
    };
    Object.defineProperty(BadFactor.prototype, "description", {
        //Возвращает свойства фактора
        get: function () {
            return this._description;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BadFactor.prototype, "hitPoints", {
        //Возвращает количество "жизней" фактора
        get: function () {
            return this._hitPoints;
        },
        //Устанавливает очки "жизней"
        set: function (value) {
            this._hitPoints = value;
        },
        enumerable: true,
        configurable: true
    });
    return BadFactor;
}());
exports.BadFactor = BadFactor;

},{}],2:[function(require,module,exports){
"use strict";
//Описание плохого фактора
var BadFactorDescription = (function () {
    function BadFactorDescription(name, qualityDamage, hitPoints, affectedResources) {
        this._name = name;
        this._damage = qualityDamage;
        this._hitPoints = hitPoints;
        this._affectedResources = affectedResources;
    }
    //Проверка, может ли данный фактор влиять на определённый ресурс.
    BadFactorDescription.prototype.canAffectTo = function (resource) {
        var checkedResourceDescription = resource.description;
        for (var _i = 0, _a = this._affectedResources; _i < _a.length; _i++) {
            var resource_1 = _a[_i];
            //на ресурс можно повлиять если он указан в списке влияния
            if (resource_1 === checkedResourceDescription) {
                return true;
            }
        }
    };
    //Повлиять на ресурс.
    BadFactorDescription.prototype.affect = function (resource) {
        resource.quality -= this._damage;
    };
    Object.defineProperty(BadFactorDescription.prototype, "name", {
        // Возвращает название плохого фактора
        get: function () {
            return this._name;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BadFactorDescription.prototype, "damage", {
        //Возвращает урон наносимый ресурсам
        get: function () {
            return this._damage;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BadFactorDescription.prototype, "hitPoints", {
        //Возвращает количество "жизней" фактора
        get: function () {
            return this._hitPoints;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BadFactorDescription.prototype, "affectedResources", {
        //Возвращает ресурсы, на которые влияет фактор
        get: function () {
            return this._affectedResources;
        },
        enumerable: true,
        configurable: true
    });
    return BadFactorDescription;
}());
exports.BadFactorDescription = BadFactorDescription;

},{}],3:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var UserValuesManager_1 = require("./UserValuesManager");
var BadFactorDescription_1 = require("./BadFactorDescription");
var util_1 = require("./util");
//Управление списком плохих факторов
var BadFactorManager = (function (_super) {
    __extends(BadFactorManager, _super);
    function BadFactorManager(resources) {
        _super.call(this, resources);
        this._entities.push(new BadFactorDescription_1.BadFactorDescription('Крысы', 15, 50, util_1.selectIndexes(resources, [0, 1, 2, 5, 8])));
        this._entities.push(new BadFactorDescription_1.BadFactorDescription('Тараканы', 5, 80, util_1.selectIndexes(resources, [2, 3, 5, 6, 7, 8])));
        this._entities.push(new BadFactorDescription_1.BadFactorDescription('Пожар', 30, 20, util_1.selectIndexes(resources, [0, 2, 4, 5, 8, 9])));
        this._entities.push(new BadFactorDescription_1.BadFactorDescription('Затопление', 20, 50, util_1.selectIndexes(resources, [0, 1, 2, 8, 9])));
        this.renderList();
    }
    BadFactorManager.prototype.getEntityName = function () {
        return 'bad-factor';
    };
    BadFactorManager.prototype.getFormWidth = function () {
        return 450;
    };
    BadFactorManager.prototype.getFormHeight = function () {
        return 650;
    };
    BadFactorManager.prototype.getMultiObjects = function (badFactor) {
        return badFactor.affectedResources;
    };
    BadFactorManager.prototype.createEntity = function (formData) {
        var resourceArray = this.getMultiSelectedObjects(formData);
        return new BadFactorDescription_1.BadFactorDescription(formData.name, formData.damage || 1, formData.hitpoints || 50, resourceArray);
    };
    BadFactorManager.prototype.setFormValues = function (badFactor) {
        this._form.find('[name="name"]').val(badFactor.name);
        this._form.find('[name="damage"]').val(badFactor.damage);
        this._form.find('[name="hitpoints"]').val(badFactor.hitPoints);
    };
    Object.defineProperty(BadFactorManager.prototype, "badFactors", {
        get: function () {
            return this._entities;
        },
        enumerable: true,
        configurable: true
    });
    return BadFactorManager;
}(UserValuesManager_1.UserValuesManager));
exports.BadFactorManager = BadFactorManager;

},{"./BadFactorDescription":2,"./UserValuesManager":11,"./util":15}],4:[function(require,module,exports){
"use strict";
//Одно место на складе
var Cell = (function () {
    function Cell(resource, storeDays) {
        //Нечто плохое, влияющее на находящийся тут ресурс
        this._badFactor = null;
        this._resource = resource;
        this._storeDays = storeDays;
        this._restStoreDays = storeDays;
    }
    Object.defineProperty(Cell.prototype, "badFactor", {
        //Возвращает плохой фактор
        get: function () {
            return this._badFactor;
        },
        //Устанавливает плохой фактор
        set: function (value) {
            this._badFactor = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Cell.prototype, "resource", {
        //Возвращает описание ресурса
        get: function () {
            return this._resource;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Cell.prototype, "storeDays", {
        //Возвращает оставшееся время хранения ресурса
        get: function () {
            return this._storeDays;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Cell.prototype, "restStoreDays", {
        //Возвращает оставшееся время хранения ресурса
        get: function () {
            return this._restStoreDays;
        },
        //Устанавливает оставшееся время хранения ресурса
        set: function (value) {
            this._restStoreDays = value;
        },
        enumerable: true,
        configurable: true
    });
    return Cell;
}());
exports.Cell = Cell;

},{}],5:[function(require,module,exports){
"use strict";
var ResourceManager_1 = require("./ResourceManager");
var BadFactorManager_1 = require("./BadFactorManager");
var ProtectorManager_1 = require("./ProtectorManager");
var Warehouse_1 = require("./Warehouse");
//Класс, отвечающий за игровой интерфейс
var GameManager = (function () {
    function GameManager() {
        var _this = this;
        //место, в котором использовать защитное средство
        this._cellIdx = -1;
        this._startScreen = $('#start-screen');
        this._entityScreen = $('#entity-screen');
        this._gameScreen = $('#game-screen');
        this._activeScreen = this._startScreen;
        this._entityScreen.hide();
        this._gameScreen.hide();
        this._messagesTemplate = Handlebars.compile($('#messages-template').html());
        this._infoTemplate = Handlebars.compile($('#info-template').html());
        this._cellTemplate = Handlebars.compile($('#cell-template').html());
        this._protectorTemplate = Handlebars.compile($('#protectors-template').html());
        this._protectorsModal = $('#protector-window').dialog({
            autoOpen: false,
            width: 400,
            height: 600,
            modal: true,
            position: { my: "top top", at: "top top", of: window },
            buttons: {}
        });
        this._loseModal = $('#lose-window').dialog({
            autoOpen: false,
            width: 350,
            height: 200,
            modal: true,
            buttons: {
                'Попробовать ещё раз': function () {
                    _this._loseModal.dialog('close');
                }
            },
            close: function () {
                _this.startGame();
            }
        });
        this._resourceManager = new ResourceManager_1.ResourceManager;
        this._badFactorManager = new BadFactorManager_1.BadFactorManager(this._resourceManager.resources);
        this._protectorManager = new ProtectorManager_1.ProtectorManager(this._badFactorManager.badFactors);
        $('#start-game').click(function () {
            _this.openScreen(_this._entityScreen);
        });
        $('#run-game').click(function () {
            _this.openScreen(_this._gameScreen);
            _this.startGame();
            setTimeout(function () {
                $('.scrollable-no').each(function (i, e) {
                    var top = Math.round($(e).offset().top);
                    $(e).css('max-height', "calc(100vh - " + top + "px)");
                });
            }, 100);
        });
        $('#next-day').click(function () {
            _this._warehouse.processDay();
            _this._days += 1;
            _this.update();
        });
        $('#increase-capacity').click(function () {
            if (_this._money >= _this._warehouse.cellCost) {
                _this._money -= _this._warehouse.cellCost;
                _this._warehouse.capacity += 1;
                _this.update();
            }
            else {
                alert('Нехватает денег');
            }
        });
        var self = this;
        $(document).on('click', '.use-protector', function () {
            self._cellIdx = +$(this).attr('data-id');
            self.showProtectorSelector();
        });
        $(document).on('click', '.protector-select', function () {
            var protectorIdx = +$(this).attr('data-id');
            var protector = self._protectorManager.protectors[protectorIdx];
            protector.protect(self._warehouse.cells[self._cellIdx]);
            self._money -= protector.cost;
            self.hideProtectorSelector();
        });
    }
    ;
    //открытие определённого экрана игры
    GameManager.prototype.openScreen = function (screen) {
        this._activeScreen.fadeOut(100, function () {
            screen.fadeIn(100);
        });
        this._activeScreen = screen;
    };
    //обновить всё визуальное состояние
    GameManager.prototype.update = function () {
        var $messages = $('#messages');
        $messages.html(this._messagesTemplate({ message: this._messages }));
        $messages.scrollTop($messages[0].scrollHeight);
        $('#cell-cost').text(this._warehouse.cellCost);
        this.updateInfo();
        this.updateCells();
        this.checkLose();
    };
    //проверить условие проигрыша
    GameManager.prototype.checkLose = function () {
        if (this._money < 0) {
            this._loseModal.dialog('open');
        }
    };
    //показать окно выбора средств защиты
    GameManager.prototype.showProtectorSelector = function () {
        var badFactor = this._warehouse.cells[this._cellIdx].badFactor;
        var tplProtectors = [];
        if (badFactor) {
            var i = 0;
            for (var _i = 0, _a = this._protectorManager.protectors; _i < _a.length; _i++) {
                var protector = _a[_i];
                if (protector.сanProtectFrom(badFactor)) {
                    tplProtectors.push({
                        can: this._money >= protector.cost,
                        protector: protector,
                        protector_id: i
                    });
                }
                ++i;
            }
            $('#protectors').html(this._protectorTemplate({
                protectors: tplProtectors
            }));
            this._protectorsModal.dialog('open');
        }
        else {
            alert('Здесь нет плохих факторов');
        }
    };
    //закрыть окно выбора средств защиты
    GameManager.prototype.hideProtectorSelector = function () {
        this._protectorsModal.dialog('close');
        this.update();
    };
    //обновить информацию для пользователя
    GameManager.prototype.updateInfo = function () {
        $('#top-info').html(this._infoTemplate({
            money: this._money,
            busy_cells: this._warehouse.busyCells,
            total_cells: this._warehouse.capacity,
            corruptedCells: this._warehouse.corruptedCells,
            days: this._days
        }));
    };
    //обновить ячейки
    GameManager.prototype.updateCells = function () {
        $('#cells').html(this._cellTemplate({
            cells: this._warehouse.cells
        }));
    };
    //отправить пользователю сообщение
    GameManager.prototype.message = function (msg) {
        this._messages.push(msg);
        this.update();
    };
    //начать слушать события склада
    GameManager.prototype.attachEventHandlers = function () {
        var _this = this;
        this._warehouse.on('cell-rent', function (cell, rent) {
            _this._money += rent;
            var cellQuality = Math.round(cell.resource.quality / cell.resource.description.quality * 100);
            _this.message("\u0412\u044B \u043F\u043E\u043B\u0443\u0447\u0438\u043B\u0438 <b>" + rent + "\u0440\u0443\u0431.</b> \u0437\u0430 \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0435\n            <i>" + cell.resource.description.name + "</i> \u0441 \u043A\u0430\u0447\u0435\u0441\u0442\u0432\u043E\u043C <b>" + cellQuality + "%</b>");
        });
        this._warehouse.on('new-cell', function (cell) {
            _this.message("\u0417\u0430\u0432\u0435\u0437\u043B\u0438 \u043D\u043E\u0432\u044B\u0439 \u0442\u043E\u0432\u0430\u0440 <b>" + cell.resource.description.name + "</b>\n            \u043D\u0430 \u0441\u0440\u043E\u043A <b>" + cell.storeDays + "\u0434\u043D.</b>");
        });
        this._warehouse.on('bad-factor-spread', function (cell, i) {
            _this.message("<font color=\"#a52a2a\">\n            \u041D\u0430 \u043C\u0435\u0441\u0442\u0435 <b>\u2116" + i + "</b> \u043F\u043E\u044F\u0432\u0438\u043B\u043E\u0441\u044C <b>" + cell.badFactor.description.name + "</b>\n            </font>");
        });
        this._warehouse.on('cell-resource-destroyed', function (cell, penalty, i) {
            //получаем штраф
            _this._money -= penalty;
            _this.message("<font color=\"#a52a2a\">\n            \u0422\u043E\u0432\u0430\u0440 \u043D\u0430 \u043C\u0435\u0441\u0442\u0435 <b>\u2116" + i + "</b> \u0431\u044B\u043B \u0443\u043D\u0438\u0447\u0442\u043E\u0436\u0435\u043D \u0438\u0437-\u0437\u0430 <b>" + cell.badFactor.description.name + "</b>.<br/>\n            \u0411\u044B\u043B\u043E \u043F\u043E\u0442\u0435\u0440\u044F\u043D\u043E <b>" + penalty + "\u0440\u0443\u0431.</b>\n            </font>");
        });
    };
    //начать игру: инициальзировать нужные переменные
    GameManager.prototype.startGame = function () {
        this._messages = [];
        this._money = 250;
        this._days = 0;
        this._warehouse = new Warehouse_1.Warehouse(this._resourceManager.resources, this._badFactorManager.badFactors);
        this.attachEventHandlers();
        this.update();
    };
    return GameManager;
}());
exports.GameManager = GameManager;

},{"./BadFactorManager":3,"./ProtectorManager":7,"./ResourceManager":10,"./Warehouse":12}],6:[function(require,module,exports){
"use strict";
//Средство защиты от плохого фактора
var Protector = (function () {
    function Protector(name, cost, damage, goodAgainst) {
        this._name = name;
        this._cost = cost;
        this._damage = damage;
        this._goodAgainst = goodAgainst;
    }
    //Проверка, может ли данное средство справиться с определённым фактором
    Protector.prototype.сanProtectFrom = function (badFactor) {
        return this._goodAgainst.indexOf(badFactor.description) !== -1;
    };
    //Защита от фактора
    Protector.prototype.protect = function (cell) {
        if (this.сanProtectFrom(cell.badFactor)) {
            cell.badFactor.hitPoints -= this._damage;
            if (cell.badFactor.hitPoints <= 0) {
                cell.badFactor = null;
            }
        }
    };
    Object.defineProperty(Protector.prototype, "cost", {
        //Возвращает стоимость средства
        get: function () {
            return this._cost;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Protector.prototype, "damage", {
        //Возвращает урон плохому фактору
        get: function () {
            return this._damage;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Protector.prototype, "name", {
        //Возвращает название средства
        get: function () {
            return this._name;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Protector.prototype, "goodAgainst", {
        //Возвращает плохие факторы, против которых данное средство работет
        get: function () {
            return this._goodAgainst;
        },
        enumerable: true,
        configurable: true
    });
    return Protector;
}());
exports.Protector = Protector;

},{}],7:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var util_1 = require("./util");
var UserValuesManager_1 = require("./UserValuesManager");
var Protector_1 = require("./Protector");
//Управление списком средств защиты
var ProtectorManager = (function (_super) {
    __extends(ProtectorManager, _super);
    function ProtectorManager(badFactors) {
        _super.call(this, badFactors);
        this._entities.push(new Protector_1.Protector('Отрава', 50, 20, util_1.selectIndexes(badFactors, [0, 1])));
        this._entities.push(new Protector_1.Protector('Инсектициды', 25, 45, util_1.selectIndexes(badFactors, [1])));
        this._entities.push(new Protector_1.Protector('Вода', 30, 20, util_1.selectIndexes(badFactors, [0, 2])));
        this._entities.push(new Protector_1.Protector('Огнетушитель', 60, 50, util_1.selectIndexes(badFactors, [2])));
        this._entities.push(new Protector_1.Protector('Силикагель', 150, 50, util_1.selectIndexes(badFactors, [0, 1, 3])));
        this._entities.push(new Protector_1.Protector('Влагопоглотитель', 50, 40, util_1.selectIndexes(badFactors, [3])));
        this.renderList();
    }
    ProtectorManager.prototype.getEntityName = function () {
        return 'protector';
    };
    ProtectorManager.prototype.getFormWidth = function () {
        return 450;
    };
    ProtectorManager.prototype.getFormHeight = function () {
        return 550;
    };
    ProtectorManager.prototype.getMultiObjects = function (protector) {
        return protector.goodAgainst;
    };
    ProtectorManager.prototype.createEntity = function (formData) {
        var badFactorArray = this.getMultiSelectedObjects(formData);
        return new Protector_1.Protector(formData.name, formData.cost || 1, formData.damage || 10, badFactorArray);
    };
    ProtectorManager.prototype.setFormValues = function (protector) {
        this._form.find('[name="name"]').val(protector.name);
        this._form.find('[name="cost"]').val(protector.cost);
        this._form.find('[name="damage"]').val(protector.damage);
    };
    Object.defineProperty(ProtectorManager.prototype, "protectors", {
        get: function () {
            return this._entities;
        },
        enumerable: true,
        configurable: true
    });
    return ProtectorManager;
}(UserValuesManager_1.UserValuesManager));
exports.ProtectorManager = ProtectorManager;

},{"./Protector":6,"./UserValuesManager":11,"./util":15}],8:[function(require,module,exports){
"use strict";
//Конкретный ресурс, который хранится на складе
var Resource = (function () {
    function Resource(description) {
        this._description = description;
        this._quality = description.quality;
    }
    Object.defineProperty(Resource.prototype, "description", {
        //Возвращает свойства ресурса
        get: function () {
            return this._description;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Resource.prototype, "quality", {
        //Возвращает качество ресурса
        get: function () {
            return this._quality;
        },
        //Устанавливает качество ресурса
        set: function (value) {
            this._quality = value;
        },
        enumerable: true,
        configurable: true
    });
    return Resource;
}());
exports.Resource = Resource;

},{}],9:[function(require,module,exports){
"use strict";
//Описание свойств ресурса
var ResourceDescription = (function () {
    function ResourceDescription(name, quality, rent, image) {
        //изображение
        this._imageUrl = null;
        this._name = name;
        this._quality = quality;
        this._rent = rent;
        if (image) {
            this._imageUrl = image;
        }
    }
    Object.defineProperty(ResourceDescription.prototype, "name", {
        //Возращает название ресурса
        get: function () {
            return this._name;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ResourceDescription.prototype, "quality", {
        //Возвращает качество ресурса
        get: function () {
            return this._quality;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ResourceDescription.prototype, "rent", {
        //Возвращает количество денег за аренду
        get: function () {
            return this._rent;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ResourceDescription.prototype, "image", {
        //Возвращает url изображения
        get: function () {
            return this._imageUrl;
        },
        enumerable: true,
        configurable: true
    });
    return ResourceDescription;
}());
exports.ResourceDescription = ResourceDescription;

},{}],10:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var ResourceDescription_1 = require("./ResourceDescription");
var UserValuesManager_1 = require("./UserValuesManager");
//Управление списком ресурсов
var ResourceManager = (function (_super) {
    __extends(ResourceManager, _super);
    function ResourceManager() {
        _super.call(this);
        this._entities.push(new ResourceDescription_1.ResourceDescription('Сено', 100, 100, '/img/seno.jpg'));
        this._entities.push(new ResourceDescription_1.ResourceDescription('Мыло', 130, 70, '/img/mylo.jpg'));
        this._entities.push(new ResourceDescription_1.ResourceDescription('Хлеб', 30, 130, '/img/hleb.jpg'));
        this._entities.push(new ResourceDescription_1.ResourceDescription('Вода', 20, 100, '/img/voda.jpg'));
        this._entities.push(new ResourceDescription_1.ResourceDescription('Бензин', 10, 200, '/img/benzin.png'));
        this._entities.push(new ResourceDescription_1.ResourceDescription('Сало', 50, 300, '/img/salo.jpg'));
        this._entities.push(new ResourceDescription_1.ResourceDescription('Бетон', 120, 60, '/img/beton.png'));
        this._entities.push(new ResourceDescription_1.ResourceDescription('Кирпич', 120, 30, '/img/kirpitch.jpg'));
        this._entities.push(new ResourceDescription_1.ResourceDescription('Сахар', 30, 140, '/img/sahar.jpg'));
        this._entities.push(new ResourceDescription_1.ResourceDescription('Порох', 10, 160, '/img/poroh.png'));
        this.renderList();
    }
    ResourceManager.prototype.getEntityName = function () {
        return 'resource';
    };
    ResourceManager.prototype.getFormWidth = function () {
        return 450;
    };
    ResourceManager.prototype.getFormHeight = function () {
        return 500;
    };
    ResourceManager.prototype.getMultiObjects = function (resource) {
        return [];
    };
    ResourceManager.prototype.createEntity = function (formData) {
        return new ResourceDescription_1.ResourceDescription(formData.name, formData.quality || 100, formData.rent || 100, formData.image || null);
    };
    ResourceManager.prototype.setFormValues = function (resource) {
        this._form.find('[name="name"]').val(resource.name);
        this._form.find('[name="quality"]').val(resource.quality);
        this._form.find('[name="rent"]').val(resource.rent);
        this._form.find('[name="image"]').val(resource.image);
    };
    Object.defineProperty(ResourceManager.prototype, "resources", {
        get: function () {
            return this._entities;
        },
        enumerable: true,
        configurable: true
    });
    return ResourceManager;
}(UserValuesManager_1.UserValuesManager));
exports.ResourceManager = ResourceManager;

},{"./ResourceDescription":9,"./UserValuesManager":11}],11:[function(require,module,exports){
"use strict";
//Общий класс для тех вещей которые пользователь добавляет/изменяет/удаляет
var UserValuesManager = (function () {
    function UserValuesManager(multiObjects) {
        var _this = this;
        //индекс обновляемого элемента
        this._updateIndex = -1;
        //список в памяти
        this._entities = [];
        //элемент мультивыбора
        this._multiSelect = null;
        //объекты для мультивыбора
        this._multiObjects = null;
        this._modal = $(this.getFormId()).dialog({
            autoOpen: false,
            height: this.getFormHeight(),
            width: this.getFormWidth(),
            modal: true,
            buttons: {
                'Применить': function () {
                    _this.saveForm();
                    _this.closeForm();
                },
                'Отмена': function () {
                    _this.closeForm();
                }
            },
            close: function () {
                _this._form.get(0).reset();
            }
        });
        this._form = this._modal.find('form');
        this._listTemplate = Handlebars.compile($(this.getTemplateId()).html());
        this._list = $(this.getListId());
        this.renderList();
        if (multiObjects) {
            this._multiObjects = multiObjects;
            this._multiSelect = this._form.find('[name="multi"]');
            this._multiSelect.multiSelect();
            this.updateResourcesList();
        }
        $(this.getCreateBtnId()).click(function () {
            _this.openForm();
        });
        var self = this;
        $(document).on('click', this.getDeleteBtnClass(), function () {
            self.deleteEntity(+$(this).parent().attr('data-idx'));
        });
        $(document).on('click', this.getUpdateBtnClass(), function () {
            self.updateEntity(+$(this).parent().attr('data-idx'));
        });
    }
    //получить id шаблона сущности
    UserValuesManager.prototype.getTemplateId = function () {
        return "#" + this.getEntityName() + "-template";
    };
    //получить id списка сущности
    UserValuesManager.prototype.getListId = function () {
        return "#" + this.getEntityName() + "-list";
    };
    //получить id формы сущности
    UserValuesManager.prototype.getFormId = function () {
        return "#" + this.getEntityName() + "-form";
    };
    //получить id кнопки создания сущности
    UserValuesManager.prototype.getCreateBtnId = function () {
        return "#create-" + this.getEntityName();
    };
    //получить class кнопки удаления сущности
    UserValuesManager.prototype.getDeleteBtnClass = function () {
        return ".delete-" + this.getEntityName();
    };
    //получить class кнопки обновления сущности
    UserValuesManager.prototype.getUpdateBtnClass = function () {
        return ".update-" + this.getEntityName();
    };
    //получить выбранные сущности из формы
    UserValuesManager.prototype.getMultiSelectedObjects = function (formData) {
        var multiIdicies = formData.multi;
        var multiArray = [];
        if (multiIdicies) {
            for (var _i = 0, multiIdicies_1 = multiIdicies; _i < multiIdicies_1.length; _i++) {
                var index = multiIdicies_1[_i];
                multiArray.push(this._multiObjects[index]);
            }
        }
        return multiArray;
    };
    //обновить список сущностей
    UserValuesManager.prototype.updateResourcesList = function () {
        if (this._multiObjects) {
            this._multiSelect.empty();
            var i = 0;
            for (var _i = 0, _a = this._multiObjects; _i < _a.length; _i++) {
                var object = _a[_i];
                this._multiSelect.append('<option value="' + i + '">' +
                    object.name +
                    '</option>');
                ++i;
            }
            this._multiSelect.multiSelect('refresh');
        }
    };
    //установить выбранные сущности на форме
    UserValuesManager.prototype.setMultiSelect = function (entity) {
        var _this = this;
        if (this._multiObjects) {
            var multiIdicies_2 = [];
            for (var _i = 0, _a = this.getMultiObjects(entity); _i < _a.length; _i++) {
                var multi = _a[_i];
                multiIdicies_2.push(this._multiObjects.indexOf(multi).toString());
            }
            setTimeout(function () {
                _this._multiSelect.multiSelect('select', multiIdicies_2);
            }, 0);
        }
    };
    //показать форму редактирования
    UserValuesManager.prototype.openForm = function () {
        this.updateResourcesList();
        this._modal.dialog('open');
        this._modal.dialog('option', 'position', { my: "top top", at: "top top", of: window });
    };
    //закрыть форму редактирования
    UserValuesManager.prototype.closeForm = function () {
        this._modal.dialog('close');
    };
    //получить данные формы редактирования
    UserValuesManager.prototype.formData = function () {
        return this._form.serializeArray().reduce(function (obj, item) {
            if (obj[item.name]) {
                if (Array.isArray(obj[item.name])) {
                    obj[item.name].push(item.value);
                }
                else {
                    obj[item.name] = [obj[item.name], item.value];
                }
            }
            else {
                obj[item.name] = item.value;
            }
            return obj;
        }, {});
    };
    //сохранить форму редактирования в сущность
    UserValuesManager.prototype.saveForm = function () {
        var data = this.formData();
        var entity = this.createEntity(data);
        if (this._updateIndex < 0) {
            this._entities.push(entity);
        }
        else {
            this._entities[this._updateIndex] = entity;
        }
        this._updateIndex = -1;
        this.renderList();
    };
    //удалить сущность
    UserValuesManager.prototype.deleteEntity = function (index) {
        this._entities.splice(index, 1);
        this.renderList();
    };
    //обновить сущность
    UserValuesManager.prototype.updateEntity = function (index) {
        this._updateIndex = index;
        var updatingEntity = this._entities[index];
        this.updateResourcesList();
        this.setFormValues(updatingEntity);
        this.setMultiSelect(updatingEntity);
        this.openForm();
    };
    //отобразить список сущностей
    UserValuesManager.prototype.renderList = function () {
        var context = {};
        context[this.getEntityName()] = this._entities;
        this._list.html(this._listTemplate(context));
    };
    return UserValuesManager;
}());
exports.UserValuesManager = UserValuesManager;

},{}],12:[function(require,module,exports){
"use strict";
var Cell_1 = require("./Cell");
var asEvented = require('./asevented.min.js');
var BadFactor_1 = require("./BadFactor");
var Resource_1 = require("./Resource");
//Склад
var Warehouse = (function () {
    function Warehouse(resources, badFactors) {
        //Максимальное количество мест на складе
        this._capacity = 10;
        //Занятые места на складе
        this._cells = [];
        this._resources = resources;
        this._badFactors = badFactors;
        for (var i = 0; i < this._capacity; ++i) {
            this._cells.push(new Cell_1.Cell(null, 0));
        }
    }
    //Вычисляет арендную плату за хранение ресурса
    Warehouse.prototype.cellRent = function (cell) {
        return Math.round(cell.resource.description.rent * cell.storeDays *
            cell.resource.quality / cell.resource.description.quality);
    };
    //Вычисляет штраф за полную порчу ресурса
    Warehouse.prototype.cellPenalty = function (cell) {
        return Math.round(cell.resource.description.rent * cell.storeDays / 2);
    };
    //обработка существующих мест
    Warehouse.prototype.processCells = function () {
        var cellsToRemove = [];
        var i = 0;
        for (var _i = 0, _a = this._cells; _i < _a.length; _i++) {
            var cell = _a[_i];
            if (cell.resource !== null) {
                if (cell.badFactor) {
                    cell.badFactor.affect(cell.resource);
                    this.emit('cell-resource-damaged', cell);
                    if (cell.resource.quality <= 0) {
                        cellsToRemove.push(i);
                        this.emit('cell-resource-destroyed', cell, this.cellPenalty(cell), i);
                        continue;
                    }
                }
                cell.restStoreDays -= 1;
                if (cell.restStoreDays <= 0) {
                    cellsToRemove.push(i);
                    this.emit('cell-rent', cell, this.cellRent(cell));
                }
            }
            ++i;
        }
        for (var _b = 0, cellsToRemove_1 = cellsToRemove; _b < cellsToRemove_1.length; _b++) {
            var idx = cellsToRemove_1[_b];
            this._cells[idx] = new Cell_1.Cell(null, 0);
        }
    };
    //распространение плохих факторов
    Warehouse.prototype.spreadBadFactors = function () {
        var i = 0;
        for (var _i = 0, _a = this._cells; _i < _a.length; _i++) {
            var cell = _a[_i];
            if (cell.resource !== null) {
                for (var _b = 0, _c = this._badFactors; _b < _c.length; _b++) {
                    var factor = _c[_b];
                    //вероятность появиться
                    if (!cell.badFactor &&
                        factor.canAffectTo(cell.resource) &&
                        Math.random() < 0.2) {
                        cell.badFactor = new BadFactor_1.BadFactor(factor);
                        this.emit('bad-factor-spread', cell, i);
                    }
                }
            }
            ++i;
        }
    };
    //получить индекс пустого места
    Warehouse.prototype.getEmptyIndex = function () {
        var i = 0;
        for (var _i = 0, _a = this._cells; _i < _a.length; _i++) {
            var cell = _a[_i];
            if (cell.resource === null) {
                return i;
            }
            ++i;
        }
    };
    //поступление новых ресурсов
    Warehouse.prototype.processNewCells = function () {
        var restCellCount = this._capacity - this.busyCells;
        for (var i = 0; i < restCellCount; ++i) {
            //вероятность нового заказа
            if (Math.random() < 0.15) {
                var randomResource = this._resources[Math.floor(Math.random() * this._resources.length)];
                var storeDays = Math.floor(Math.random() * 20) + 1;
                var cell = new Cell_1.Cell(new Resource_1.Resource(randomResource), storeDays);
                this._cells[this.getEmptyIndex()] = cell;
                this.emit('new-cell', cell);
            }
        }
    };
    //Смоделировать события, прошедшие за один день
    Warehouse.prototype.processDay = function () {
        this.processCells();
        this.spreadBadFactors();
        this.processNewCells();
    };
    Object.defineProperty(Warehouse.prototype, "cells", {
        //Возвращает массив занятых ячеек склада
        get: function () {
            return this._cells;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Warehouse.prototype, "cellCost", {
        //Возвращает стоимость увеличения вместимости склада на одно место
        get: function () {
            return this._capacity * 300;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Warehouse.prototype, "capacity", {
        //Возвращает максимальное количество мест на складе
        get: function () {
            return this._capacity;
        },
        //Устанавливает максимальное количество мест на складе
        set: function (value) {
            if (this._capacity < value) {
                var diff = value - this._capacity;
                for (var i = 0; i < diff; ++i) {
                    this._cells.push(new Cell_1.Cell(null, 0));
                }
            }
            this._capacity = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Warehouse.prototype, "busyCells", {
        //Возвращает количество занятых мест на складе
        get: function () {
            return this._cells.filter(function (cell) { return cell.resource != null; }).length;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Warehouse.prototype, "corruptedCells", {
        //Возвращает номера занятых мест, в которых есть плохой фактор
        get: function () {
            var i = 0;
            var corrupted = [];
            for (var _i = 0, _a = this.cells; _i < _a.length; _i++) {
                var cell = _a[_i];
                if (cell.badFactor) {
                    corrupted.push(i);
                }
                ++i;
            }
            return corrupted;
        },
        enumerable: true,
        configurable: true
    });
    return Warehouse;
}());
exports.Warehouse = Warehouse;
//noinspection TypeScriptUnresolvedFunction
asEvented.call(Warehouse.prototype);

},{"./BadFactor":1,"./Cell":4,"./Resource":8,"./asevented.min.js":13}],13:[function(require,module,exports){
/*! asEvented v0.4.3 github.com/mkuklis/asEvented | Dual licensed under the MIT or GPL Version 2 licenses. */
(function (f, g, b) { "undefined" !== typeof module ? module.exports = b() : "undefined" !== typeof require && "object" === typeof define.amd ? define(b) : g[f] = b(); })("asEvented", this, function () {
    return function () {
        function f(h, e) { var a, d, c = this.events = this.events || {}, b = h.split(/\s+/), k = b.length; for (a = 0; a < k; a++)
            c[d = b[a]] = c[d] || [], c[d].push(e); return this; }
        function g(h, e) { var a = function () { e.apply(this, n.call(arguments)); this.unbind(h, a); }; this.bind(h, a); return this; }
        function b(h, e) {
            var a, d, c, b, k, m = this.events;
            if (m) {
                k = h.split(/\s+/);
                d = 0;
                for (b = k.length; d < b; d++)
                    if (!1 !== (a = k[d]) in m) {
                        if (e)
                            a: {
                                c = m[a];
                                var f = e, l = void 0, g = void 0;
                                if (p && c.indexOf === p)
                                    c = c.indexOf(f);
                                else {
                                    l = 0;
                                    for (g = c.length; l < g; l++)
                                        if (c[l] === f) {
                                            c = l;
                                            break a;
                                        }
                                    c = -1;
                                }
                            }
                        else
                            c = 0;
                        -1 !== c && m[a].splice(c, 1);
                    }
                return this;
            }
        }
        function r(b) { var e, a, d = this.events; if (d && !1 !== b in d) {
            e = n.call(arguments, 1);
            for (a = d[b].length - 1; 0 <= a; a--)
                d[b][a].apply(this, e);
            return this;
        } }
        var q = Array.prototype, p = q.indexOf, n = q.slice;
        return function () {
            this.bind = this.on = f;
            this.unbind = this.off = this.removeListener = b;
            this.trigger = this.emit = r;
            this.one = this.once = g;
            return this;
        };
    }();
});

},{}],14:[function(require,module,exports){
"use strict";
var GameManager_1 = require("./GameManager");
$(function () {
    var _ = new GameManager_1.GameManager;
});

},{"./GameManager":5}],15:[function(require,module,exports){
"use strict";
//выбор значений массива по индексам
function selectIndexes(arr, indexes) {
    var res = [];
    for (var _i = 0, indexes_1 = indexes; _i < indexes_1.length; _i++) {
        var i = indexes_1[_i];
        res.push(arr[i]);
    }
    return res;
}
exports.selectIndexes = selectIndexes;

},{}]},{},[14])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL3VzZXJyL9CU0L7QutGD0LzQtdC90YLRiy8yY3VyL3ByYWN0aWNlL25vZGVfbW9kdWxlcy9ndWxwLWJyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXItcGFjay9fcHJlbHVkZS5qcyIsIi90bXAvODUxMjA3YWEtZjU1OS00MjQ2LWFjODctZThjYTUzYmFiN2NjL0JhZEZhY3Rvci5qcyIsIi90bXAvODUxMjA3YWEtZjU1OS00MjQ2LWFjODctZThjYTUzYmFiN2NjL0JhZEZhY3RvckRlc2NyaXB0aW9uLmpzIiwiL3RtcC84NTEyMDdhYS1mNTU5LTQyNDYtYWM4Ny1lOGNhNTNiYWI3Y2MvQmFkRmFjdG9yTWFuYWdlci5qcyIsIi90bXAvODUxMjA3YWEtZjU1OS00MjQ2LWFjODctZThjYTUzYmFiN2NjL0NlbGwuanMiLCIvdG1wLzg1MTIwN2FhLWY1NTktNDI0Ni1hYzg3LWU4Y2E1M2JhYjdjYy9HYW1lTWFuYWdlci5qcyIsIi90bXAvODUxMjA3YWEtZjU1OS00MjQ2LWFjODctZThjYTUzYmFiN2NjL1Byb3RlY3Rvci5qcyIsIi90bXAvODUxMjA3YWEtZjU1OS00MjQ2LWFjODctZThjYTUzYmFiN2NjL1Byb3RlY3Rvck1hbmFnZXIuanMiLCIvdG1wLzg1MTIwN2FhLWY1NTktNDI0Ni1hYzg3LWU4Y2E1M2JhYjdjYy9SZXNvdXJjZS5qcyIsIi90bXAvODUxMjA3YWEtZjU1OS00MjQ2LWFjODctZThjYTUzYmFiN2NjL1Jlc291cmNlRGVzY3JpcHRpb24uanMiLCIvdG1wLzg1MTIwN2FhLWY1NTktNDI0Ni1hYzg3LWU4Y2E1M2JhYjdjYy9SZXNvdXJjZU1hbmFnZXIuanMiLCIvdG1wLzg1MTIwN2FhLWY1NTktNDI0Ni1hYzg3LWU4Y2E1M2JhYjdjYy9Vc2VyVmFsdWVzTWFuYWdlci5qcyIsIi90bXAvODUxMjA3YWEtZjU1OS00MjQ2LWFjODctZThjYTUzYmFiN2NjL1dhcmVob3VzZS5qcyIsIi90bXAvODUxMjA3YWEtZjU1OS00MjQ2LWFjODctZThjYTUzYmFiN2NjL2FzZXZlbnRlZC5taW4uanMiLCIvdG1wLzg1MTIwN2FhLWY1NTktNDI0Ni1hYzg3LWU4Y2E1M2JhYjdjYy9mYWtlX2Y0MDk1NWZjLmpzIiwiL3RtcC84NTEyMDdhYS1mNTU5LTQyNDYtYWM4Ny1lOGNhNTNiYWI3Y2MvdXRpbC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN0Q0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzNEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNuREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3JEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNuTUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDekRBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNyREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDOUJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2hEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDeERBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3BMQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUMzS0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNwREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ0xBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIGUodCxuLHIpe2Z1bmN0aW9uIHMobyx1KXtpZighbltvXSl7aWYoIXRbb10pe3ZhciBhPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7aWYoIXUmJmEpcmV0dXJuIGEobywhMCk7aWYoaSlyZXR1cm4gaShvLCEwKTt0aHJvdyBuZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK28rXCInXCIpfXZhciBmPW5bb109e2V4cG9ydHM6e319O3Rbb11bMF0uY2FsbChmLmV4cG9ydHMsZnVuY3Rpb24oZSl7dmFyIG49dFtvXVsxXVtlXTtyZXR1cm4gcyhuP246ZSl9LGYsZi5leHBvcnRzLGUsdCxuLHIpfXJldHVybiBuW29dLmV4cG9ydHN9dmFyIGk9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtmb3IodmFyIG89MDtvPHIubGVuZ3RoO28rKylzKHJbb10pO3JldHVybiBzfSkiLCJcInVzZSBzdHJpY3RcIjtcbi8v0J/Qu9C+0YXQvtC5INGE0LDQutGC0L7RgFxudmFyIEJhZEZhY3RvciA9IChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gQmFkRmFjdG9yKGRlc2NyaXB0aW9uKSB7XG4gICAgICAgIHRoaXMuX2Rlc2NyaXB0aW9uID0gZGVzY3JpcHRpb247XG4gICAgICAgIHRoaXMuX2hpdFBvaW50cyA9IGRlc2NyaXB0aW9uLmhpdFBvaW50cztcbiAgICB9XG4gICAgLy/Qn9GA0L7QstC10YDQutCwLCDQvNC+0LbQtdGCINC70Lgg0LTQsNC90L3Ri9C5INGE0LDQutGC0L7RgCDQstC70LjRj9GC0Ywg0L3QsCDQvtC/0YDQtdC00LXQu9GR0L3QvdGL0Lkg0YDQtdGB0YPRgNGBLiDQlNC10LvQtdCz0LjRgNGD0LXRgtGB0Y8g0YHQstC+0LnRgdGC0LLQsNC8INGA0LXRgdGD0YDRgdCwXG4gICAgQmFkRmFjdG9yLnByb3RvdHlwZS5jYW5BZmZlY3RUbyA9IGZ1bmN0aW9uIChyZXNvdXJjZSkge1xuICAgICAgICByZXR1cm4gdGhpcy5fZGVzY3JpcHRpb24uY2FuQWZmZWN0VG8ocmVzb3VyY2UpO1xuICAgIH07XG4gICAgLy/Qn9C+0LLQu9C40Y/RgtGMINC90LAg0YDQtdGB0YPRgNGBLiDQlNC10LvQtdCz0LjRgNGD0LXRgtGB0Y8g0YHQstC+0LnRgdGC0LLQsNC8INGA0LXRgdGD0YDRgdCwXG4gICAgQmFkRmFjdG9yLnByb3RvdHlwZS5hZmZlY3QgPSBmdW5jdGlvbiAocmVzb3VyY2UpIHtcbiAgICAgICAgdGhpcy5fZGVzY3JpcHRpb24uYWZmZWN0KHJlc291cmNlKTtcbiAgICB9O1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShCYWRGYWN0b3IucHJvdG90eXBlLCBcImRlc2NyaXB0aW9uXCIsIHtcbiAgICAgICAgLy/QktC+0LfQstGA0LDRidCw0LXRgiDRgdCy0L7QudGB0YLQstCwINGE0LDQutGC0L7RgNCwXG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2Rlc2NyaXB0aW9uO1xuICAgICAgICB9LFxuICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9KTtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoQmFkRmFjdG9yLnByb3RvdHlwZSwgXCJoaXRQb2ludHNcIiwge1xuICAgICAgICAvL9CS0L7Qt9Cy0YDQsNGJ0LDQtdGCINC60L7Qu9C40YfQtdGB0YLQstC+IFwi0LbQuNC30L3QtdC5XCIg0YTQsNC60YLQvtGA0LBcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5faGl0UG9pbnRzO1xuICAgICAgICB9LFxuICAgICAgICAvL9Cj0YHRgtCw0L3QsNCy0LvQuNCy0LDQtdGCINC+0YfQutC4IFwi0LbQuNC30L3QtdC5XCJcbiAgICAgICAgc2V0OiBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgICAgIHRoaXMuX2hpdFBvaW50cyA9IHZhbHVlO1xuICAgICAgICB9LFxuICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9KTtcbiAgICByZXR1cm4gQmFkRmFjdG9yO1xufSgpKTtcbmV4cG9ydHMuQmFkRmFjdG9yID0gQmFkRmFjdG9yO1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG4vL9Ce0L/QuNGB0LDQvdC40LUg0L/Qu9C+0YXQvtCz0L4g0YTQsNC60YLQvtGA0LBcbnZhciBCYWRGYWN0b3JEZXNjcmlwdGlvbiA9IChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gQmFkRmFjdG9yRGVzY3JpcHRpb24obmFtZSwgcXVhbGl0eURhbWFnZSwgaGl0UG9pbnRzLCBhZmZlY3RlZFJlc291cmNlcykge1xuICAgICAgICB0aGlzLl9uYW1lID0gbmFtZTtcbiAgICAgICAgdGhpcy5fZGFtYWdlID0gcXVhbGl0eURhbWFnZTtcbiAgICAgICAgdGhpcy5faGl0UG9pbnRzID0gaGl0UG9pbnRzO1xuICAgICAgICB0aGlzLl9hZmZlY3RlZFJlc291cmNlcyA9IGFmZmVjdGVkUmVzb3VyY2VzO1xuICAgIH1cbiAgICAvL9Cf0YDQvtCy0LXRgNC60LAsINC80L7QttC10YIg0LvQuCDQtNCw0L3QvdGL0Lkg0YTQsNC60YLQvtGAINCy0LvQuNGP0YLRjCDQvdCwINC+0L/RgNC10LTQtdC70ZHQvdC90YvQuSDRgNC10YHRg9GA0YEuXG4gICAgQmFkRmFjdG9yRGVzY3JpcHRpb24ucHJvdG90eXBlLmNhbkFmZmVjdFRvID0gZnVuY3Rpb24gKHJlc291cmNlKSB7XG4gICAgICAgIHZhciBjaGVja2VkUmVzb3VyY2VEZXNjcmlwdGlvbiA9IHJlc291cmNlLmRlc2NyaXB0aW9uO1xuICAgICAgICBmb3IgKHZhciBfaSA9IDAsIF9hID0gdGhpcy5fYWZmZWN0ZWRSZXNvdXJjZXM7IF9pIDwgX2EubGVuZ3RoOyBfaSsrKSB7XG4gICAgICAgICAgICB2YXIgcmVzb3VyY2VfMSA9IF9hW19pXTtcbiAgICAgICAgICAgIC8v0L3QsCDRgNC10YHRg9GA0YEg0LzQvtC20L3QviDQv9C+0LLQu9C40Y/RgtGMINC10YHQu9C4INC+0L0g0YPQutCw0LfQsNC9INCyINGB0L/QuNGB0LrQtSDQstC70LjRj9C90LjRj1xuICAgICAgICAgICAgaWYgKHJlc291cmNlXzEgPT09IGNoZWNrZWRSZXNvdXJjZURlc2NyaXB0aW9uKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9O1xuICAgIC8v0J/QvtCy0LvQuNGP0YLRjCDQvdCwINGA0LXRgdGD0YDRgS5cbiAgICBCYWRGYWN0b3JEZXNjcmlwdGlvbi5wcm90b3R5cGUuYWZmZWN0ID0gZnVuY3Rpb24gKHJlc291cmNlKSB7XG4gICAgICAgIHJlc291cmNlLnF1YWxpdHkgLT0gdGhpcy5fZGFtYWdlO1xuICAgIH07XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KEJhZEZhY3RvckRlc2NyaXB0aW9uLnByb3RvdHlwZSwgXCJuYW1lXCIsIHtcbiAgICAgICAgLy8g0JLQvtC30LLRgNCw0YnQsNC10YIg0L3QsNC30LLQsNC90LjQtSDQv9C70L7RhdC+0LPQviDRhNCw0LrRgtC+0YDQsFxuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9uYW1lO1xuICAgICAgICB9LFxuICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9KTtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoQmFkRmFjdG9yRGVzY3JpcHRpb24ucHJvdG90eXBlLCBcImRhbWFnZVwiLCB7XG4gICAgICAgIC8v0JLQvtC30LLRgNCw0YnQsNC10YIg0YPRgNC+0L0g0L3QsNC90L7RgdC40LzRi9C5INGA0LXRgdGD0YDRgdCw0LxcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fZGFtYWdlO1xuICAgICAgICB9LFxuICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9KTtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoQmFkRmFjdG9yRGVzY3JpcHRpb24ucHJvdG90eXBlLCBcImhpdFBvaW50c1wiLCB7XG4gICAgICAgIC8v0JLQvtC30LLRgNCw0YnQsNC10YIg0LrQvtC70LjRh9C10YHRgtCy0L4gXCLQttC40LfQvdC10LlcIiDRhNCw0LrRgtC+0YDQsFxuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9oaXRQb2ludHM7XG4gICAgICAgIH0sXG4gICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0pO1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShCYWRGYWN0b3JEZXNjcmlwdGlvbi5wcm90b3R5cGUsIFwiYWZmZWN0ZWRSZXNvdXJjZXNcIiwge1xuICAgICAgICAvL9CS0L7Qt9Cy0YDQsNGJ0LDQtdGCINGA0LXRgdGD0YDRgdGLLCDQvdCwINC60L7RgtC+0YDRi9C1INCy0LvQuNGP0LXRgiDRhNCw0LrRgtC+0YBcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fYWZmZWN0ZWRSZXNvdXJjZXM7XG4gICAgICAgIH0sXG4gICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0pO1xuICAgIHJldHVybiBCYWRGYWN0b3JEZXNjcmlwdGlvbjtcbn0oKSk7XG5leHBvcnRzLkJhZEZhY3RvckRlc2NyaXB0aW9uID0gQmFkRmFjdG9yRGVzY3JpcHRpb247XG4iLCJcInVzZSBzdHJpY3RcIjtcbnZhciBfX2V4dGVuZHMgPSAodGhpcyAmJiB0aGlzLl9fZXh0ZW5kcykgfHwgZnVuY3Rpb24gKGQsIGIpIHtcbiAgICBmb3IgKHZhciBwIGluIGIpIGlmIChiLmhhc093blByb3BlcnR5KHApKSBkW3BdID0gYltwXTtcbiAgICBmdW5jdGlvbiBfXygpIHsgdGhpcy5jb25zdHJ1Y3RvciA9IGQ7IH1cbiAgICBkLnByb3RvdHlwZSA9IGIgPT09IG51bGwgPyBPYmplY3QuY3JlYXRlKGIpIDogKF9fLnByb3RvdHlwZSA9IGIucHJvdG90eXBlLCBuZXcgX18oKSk7XG59O1xudmFyIFVzZXJWYWx1ZXNNYW5hZ2VyXzEgPSByZXF1aXJlKFwiLi9Vc2VyVmFsdWVzTWFuYWdlclwiKTtcbnZhciBCYWRGYWN0b3JEZXNjcmlwdGlvbl8xID0gcmVxdWlyZShcIi4vQmFkRmFjdG9yRGVzY3JpcHRpb25cIik7XG52YXIgdXRpbF8xID0gcmVxdWlyZShcIi4vdXRpbFwiKTtcbi8v0KPQv9GA0LDQstC70LXQvdC40LUg0YHQv9C40YHQutC+0Lwg0L/Qu9C+0YXQuNGFINGE0LDQutGC0L7RgNC+0LJcbnZhciBCYWRGYWN0b3JNYW5hZ2VyID0gKGZ1bmN0aW9uIChfc3VwZXIpIHtcbiAgICBfX2V4dGVuZHMoQmFkRmFjdG9yTWFuYWdlciwgX3N1cGVyKTtcbiAgICBmdW5jdGlvbiBCYWRGYWN0b3JNYW5hZ2VyKHJlc291cmNlcykge1xuICAgICAgICBfc3VwZXIuY2FsbCh0aGlzLCByZXNvdXJjZXMpO1xuICAgICAgICB0aGlzLl9lbnRpdGllcy5wdXNoKG5ldyBCYWRGYWN0b3JEZXNjcmlwdGlvbl8xLkJhZEZhY3RvckRlc2NyaXB0aW9uKCfQmtGA0YvRgdGLJywgMTUsIDUwLCB1dGlsXzEuc2VsZWN0SW5kZXhlcyhyZXNvdXJjZXMsIFswLCAxLCAyLCA1LCA4XSkpKTtcbiAgICAgICAgdGhpcy5fZW50aXRpZXMucHVzaChuZXcgQmFkRmFjdG9yRGVzY3JpcHRpb25fMS5CYWRGYWN0b3JEZXNjcmlwdGlvbign0KLQsNGA0LDQutCw0L3RiycsIDUsIDgwLCB1dGlsXzEuc2VsZWN0SW5kZXhlcyhyZXNvdXJjZXMsIFsyLCAzLCA1LCA2LCA3LCA4XSkpKTtcbiAgICAgICAgdGhpcy5fZW50aXRpZXMucHVzaChuZXcgQmFkRmFjdG9yRGVzY3JpcHRpb25fMS5CYWRGYWN0b3JEZXNjcmlwdGlvbign0J/QvtC20LDRgCcsIDMwLCAyMCwgdXRpbF8xLnNlbGVjdEluZGV4ZXMocmVzb3VyY2VzLCBbMCwgMiwgNCwgNSwgOCwgOV0pKSk7XG4gICAgICAgIHRoaXMuX2VudGl0aWVzLnB1c2gobmV3IEJhZEZhY3RvckRlc2NyaXB0aW9uXzEuQmFkRmFjdG9yRGVzY3JpcHRpb24oJ9CX0LDRgtC+0L/Qu9C10L3QuNC1JywgMjAsIDUwLCB1dGlsXzEuc2VsZWN0SW5kZXhlcyhyZXNvdXJjZXMsIFswLCAxLCAyLCA4LCA5XSkpKTtcbiAgICAgICAgdGhpcy5yZW5kZXJMaXN0KCk7XG4gICAgfVxuICAgIEJhZEZhY3Rvck1hbmFnZXIucHJvdG90eXBlLmdldEVudGl0eU5hbWUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiAnYmFkLWZhY3Rvcic7XG4gICAgfTtcbiAgICBCYWRGYWN0b3JNYW5hZ2VyLnByb3RvdHlwZS5nZXRGb3JtV2lkdGggPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiA0NTA7XG4gICAgfTtcbiAgICBCYWRGYWN0b3JNYW5hZ2VyLnByb3RvdHlwZS5nZXRGb3JtSGVpZ2h0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gNjUwO1xuICAgIH07XG4gICAgQmFkRmFjdG9yTWFuYWdlci5wcm90b3R5cGUuZ2V0TXVsdGlPYmplY3RzID0gZnVuY3Rpb24gKGJhZEZhY3Rvcikge1xuICAgICAgICByZXR1cm4gYmFkRmFjdG9yLmFmZmVjdGVkUmVzb3VyY2VzO1xuICAgIH07XG4gICAgQmFkRmFjdG9yTWFuYWdlci5wcm90b3R5cGUuY3JlYXRlRW50aXR5ID0gZnVuY3Rpb24gKGZvcm1EYXRhKSB7XG4gICAgICAgIHZhciByZXNvdXJjZUFycmF5ID0gdGhpcy5nZXRNdWx0aVNlbGVjdGVkT2JqZWN0cyhmb3JtRGF0YSk7XG4gICAgICAgIHJldHVybiBuZXcgQmFkRmFjdG9yRGVzY3JpcHRpb25fMS5CYWRGYWN0b3JEZXNjcmlwdGlvbihmb3JtRGF0YS5uYW1lLCBmb3JtRGF0YS5kYW1hZ2UgfHwgMSwgZm9ybURhdGEuaGl0cG9pbnRzIHx8IDUwLCByZXNvdXJjZUFycmF5KTtcbiAgICB9O1xuICAgIEJhZEZhY3Rvck1hbmFnZXIucHJvdG90eXBlLnNldEZvcm1WYWx1ZXMgPSBmdW5jdGlvbiAoYmFkRmFjdG9yKSB7XG4gICAgICAgIHRoaXMuX2Zvcm0uZmluZCgnW25hbWU9XCJuYW1lXCJdJykudmFsKGJhZEZhY3Rvci5uYW1lKTtcbiAgICAgICAgdGhpcy5fZm9ybS5maW5kKCdbbmFtZT1cImRhbWFnZVwiXScpLnZhbChiYWRGYWN0b3IuZGFtYWdlKTtcbiAgICAgICAgdGhpcy5fZm9ybS5maW5kKCdbbmFtZT1cImhpdHBvaW50c1wiXScpLnZhbChiYWRGYWN0b3IuaGl0UG9pbnRzKTtcbiAgICB9O1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShCYWRGYWN0b3JNYW5hZ2VyLnByb3RvdHlwZSwgXCJiYWRGYWN0b3JzXCIsIHtcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fZW50aXRpZXM7XG4gICAgICAgIH0sXG4gICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0pO1xuICAgIHJldHVybiBCYWRGYWN0b3JNYW5hZ2VyO1xufShVc2VyVmFsdWVzTWFuYWdlcl8xLlVzZXJWYWx1ZXNNYW5hZ2VyKSk7XG5leHBvcnRzLkJhZEZhY3Rvck1hbmFnZXIgPSBCYWRGYWN0b3JNYW5hZ2VyO1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG4vL9Ce0LTQvdC+INC80LXRgdGC0L4g0L3QsCDRgdC60LvQsNC00LVcbnZhciBDZWxsID0gKGZ1bmN0aW9uICgpIHtcbiAgICBmdW5jdGlvbiBDZWxsKHJlc291cmNlLCBzdG9yZURheXMpIHtcbiAgICAgICAgLy/QndC10YfRgtC+INC/0LvQvtGF0L7QtSwg0LLQu9C40Y/RjtGJ0LXQtSDQvdCwINC90LDRhdC+0LTRj9GJ0LjQudGB0Y8g0YLRg9GCINGA0LXRgdGD0YDRgVxuICAgICAgICB0aGlzLl9iYWRGYWN0b3IgPSBudWxsO1xuICAgICAgICB0aGlzLl9yZXNvdXJjZSA9IHJlc291cmNlO1xuICAgICAgICB0aGlzLl9zdG9yZURheXMgPSBzdG9yZURheXM7XG4gICAgICAgIHRoaXMuX3Jlc3RTdG9yZURheXMgPSBzdG9yZURheXM7XG4gICAgfVxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShDZWxsLnByb3RvdHlwZSwgXCJiYWRGYWN0b3JcIiwge1xuICAgICAgICAvL9CS0L7Qt9Cy0YDQsNGJ0LDQtdGCINC/0LvQvtGF0L7QuSDRhNCw0LrRgtC+0YBcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fYmFkRmFjdG9yO1xuICAgICAgICB9LFxuICAgICAgICAvL9Cj0YHRgtCw0L3QsNCy0LvQuNCy0LDQtdGCINC/0LvQvtGF0L7QuSDRhNCw0LrRgtC+0YBcbiAgICAgICAgc2V0OiBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgICAgIHRoaXMuX2JhZEZhY3RvciA9IHZhbHVlO1xuICAgICAgICB9LFxuICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9KTtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoQ2VsbC5wcm90b3R5cGUsIFwicmVzb3VyY2VcIiwge1xuICAgICAgICAvL9CS0L7Qt9Cy0YDQsNGJ0LDQtdGCINC+0L/QuNGB0LDQvdC40LUg0YDQtdGB0YPRgNGB0LBcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fcmVzb3VyY2U7XG4gICAgICAgIH0sXG4gICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0pO1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShDZWxsLnByb3RvdHlwZSwgXCJzdG9yZURheXNcIiwge1xuICAgICAgICAvL9CS0L7Qt9Cy0YDQsNGJ0LDQtdGCINC+0YHRgtCw0LLRiNC10LXRgdGPINCy0YDQtdC80Y8g0YXRgNCw0L3QtdC90LjRjyDRgNC10YHRg9GA0YHQsFxuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9zdG9yZURheXM7XG4gICAgICAgIH0sXG4gICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0pO1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShDZWxsLnByb3RvdHlwZSwgXCJyZXN0U3RvcmVEYXlzXCIsIHtcbiAgICAgICAgLy/QktC+0LfQstGA0LDRidCw0LXRgiDQvtGB0YLQsNCy0YjQtdC10YHRjyDQstGA0LXQvNGPINGF0YDQsNC90LXQvdC40Y8g0YDQtdGB0YPRgNGB0LBcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fcmVzdFN0b3JlRGF5cztcbiAgICAgICAgfSxcbiAgICAgICAgLy/Qo9GB0YLQsNC90LDQstC70LjQstCw0LXRgiDQvtGB0YLQsNCy0YjQtdC10YHRjyDQstGA0LXQvNGPINGF0YDQsNC90LXQvdC40Y8g0YDQtdGB0YPRgNGB0LBcbiAgICAgICAgc2V0OiBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgICAgIHRoaXMuX3Jlc3RTdG9yZURheXMgPSB2YWx1ZTtcbiAgICAgICAgfSxcbiAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSk7XG4gICAgcmV0dXJuIENlbGw7XG59KCkpO1xuZXhwb3J0cy5DZWxsID0gQ2VsbDtcbiIsIlwidXNlIHN0cmljdFwiO1xudmFyIFJlc291cmNlTWFuYWdlcl8xID0gcmVxdWlyZShcIi4vUmVzb3VyY2VNYW5hZ2VyXCIpO1xudmFyIEJhZEZhY3Rvck1hbmFnZXJfMSA9IHJlcXVpcmUoXCIuL0JhZEZhY3Rvck1hbmFnZXJcIik7XG52YXIgUHJvdGVjdG9yTWFuYWdlcl8xID0gcmVxdWlyZShcIi4vUHJvdGVjdG9yTWFuYWdlclwiKTtcbnZhciBXYXJlaG91c2VfMSA9IHJlcXVpcmUoXCIuL1dhcmVob3VzZVwiKTtcbi8v0JrQu9Cw0YHRgSwg0L7RgtCy0LXRh9Cw0Y7RidC40Lkg0LfQsCDQuNCz0YDQvtCy0L7QuSDQuNC90YLQtdGA0YTQtdC50YFcbnZhciBHYW1lTWFuYWdlciA9IChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gR2FtZU1hbmFnZXIoKSB7XG4gICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgIC8v0LzQtdGB0YLQviwg0LIg0LrQvtGC0L7RgNC+0Lwg0LjRgdC/0L7Qu9GM0LfQvtCy0LDRgtGMINC30LDRidC40YLQvdC+0LUg0YHRgNC10LTRgdGC0LLQvlxuICAgICAgICB0aGlzLl9jZWxsSWR4ID0gLTE7XG4gICAgICAgIHRoaXMuX3N0YXJ0U2NyZWVuID0gJCgnI3N0YXJ0LXNjcmVlbicpO1xuICAgICAgICB0aGlzLl9lbnRpdHlTY3JlZW4gPSAkKCcjZW50aXR5LXNjcmVlbicpO1xuICAgICAgICB0aGlzLl9nYW1lU2NyZWVuID0gJCgnI2dhbWUtc2NyZWVuJyk7XG4gICAgICAgIHRoaXMuX2FjdGl2ZVNjcmVlbiA9IHRoaXMuX3N0YXJ0U2NyZWVuO1xuICAgICAgICB0aGlzLl9lbnRpdHlTY3JlZW4uaGlkZSgpO1xuICAgICAgICB0aGlzLl9nYW1lU2NyZWVuLmhpZGUoKTtcbiAgICAgICAgdGhpcy5fbWVzc2FnZXNUZW1wbGF0ZSA9IEhhbmRsZWJhcnMuY29tcGlsZSgkKCcjbWVzc2FnZXMtdGVtcGxhdGUnKS5odG1sKCkpO1xuICAgICAgICB0aGlzLl9pbmZvVGVtcGxhdGUgPSBIYW5kbGViYXJzLmNvbXBpbGUoJCgnI2luZm8tdGVtcGxhdGUnKS5odG1sKCkpO1xuICAgICAgICB0aGlzLl9jZWxsVGVtcGxhdGUgPSBIYW5kbGViYXJzLmNvbXBpbGUoJCgnI2NlbGwtdGVtcGxhdGUnKS5odG1sKCkpO1xuICAgICAgICB0aGlzLl9wcm90ZWN0b3JUZW1wbGF0ZSA9IEhhbmRsZWJhcnMuY29tcGlsZSgkKCcjcHJvdGVjdG9ycy10ZW1wbGF0ZScpLmh0bWwoKSk7XG4gICAgICAgIHRoaXMuX3Byb3RlY3RvcnNNb2RhbCA9ICQoJyNwcm90ZWN0b3Itd2luZG93JykuZGlhbG9nKHtcbiAgICAgICAgICAgIGF1dG9PcGVuOiBmYWxzZSxcbiAgICAgICAgICAgIHdpZHRoOiA0MDAsXG4gICAgICAgICAgICBoZWlnaHQ6IDYwMCxcbiAgICAgICAgICAgIG1vZGFsOiB0cnVlLFxuICAgICAgICAgICAgcG9zaXRpb246IHsgbXk6IFwidG9wIHRvcFwiLCBhdDogXCJ0b3AgdG9wXCIsIG9mOiB3aW5kb3cgfSxcbiAgICAgICAgICAgIGJ1dHRvbnM6IHt9XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLl9sb3NlTW9kYWwgPSAkKCcjbG9zZS13aW5kb3cnKS5kaWFsb2coe1xuICAgICAgICAgICAgYXV0b09wZW46IGZhbHNlLFxuICAgICAgICAgICAgd2lkdGg6IDM1MCxcbiAgICAgICAgICAgIGhlaWdodDogMjAwLFxuICAgICAgICAgICAgbW9kYWw6IHRydWUsXG4gICAgICAgICAgICBidXR0b25zOiB7XG4gICAgICAgICAgICAgICAgJ9Cf0L7Qv9GA0L7QsdC+0LLQsNGC0Ywg0LXRidGRINGA0LDQtyc6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgX3RoaXMuX2xvc2VNb2RhbC5kaWFsb2coJ2Nsb3NlJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGNsb3NlOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgX3RoaXMuc3RhcnRHYW1lKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLl9yZXNvdXJjZU1hbmFnZXIgPSBuZXcgUmVzb3VyY2VNYW5hZ2VyXzEuUmVzb3VyY2VNYW5hZ2VyO1xuICAgICAgICB0aGlzLl9iYWRGYWN0b3JNYW5hZ2VyID0gbmV3IEJhZEZhY3Rvck1hbmFnZXJfMS5CYWRGYWN0b3JNYW5hZ2VyKHRoaXMuX3Jlc291cmNlTWFuYWdlci5yZXNvdXJjZXMpO1xuICAgICAgICB0aGlzLl9wcm90ZWN0b3JNYW5hZ2VyID0gbmV3IFByb3RlY3Rvck1hbmFnZXJfMS5Qcm90ZWN0b3JNYW5hZ2VyKHRoaXMuX2JhZEZhY3Rvck1hbmFnZXIuYmFkRmFjdG9ycyk7XG4gICAgICAgICQoJyNzdGFydC1nYW1lJykuY2xpY2soZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgX3RoaXMub3BlblNjcmVlbihfdGhpcy5fZW50aXR5U2NyZWVuKTtcbiAgICAgICAgfSk7XG4gICAgICAgICQoJyNydW4tZ2FtZScpLmNsaWNrKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIF90aGlzLm9wZW5TY3JlZW4oX3RoaXMuX2dhbWVTY3JlZW4pO1xuICAgICAgICAgICAgX3RoaXMuc3RhcnRHYW1lKCk7XG4gICAgICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAkKCcuc2Nyb2xsYWJsZS1ubycpLmVhY2goZnVuY3Rpb24gKGksIGUpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHRvcCA9IE1hdGgucm91bmQoJChlKS5vZmZzZXQoKS50b3ApO1xuICAgICAgICAgICAgICAgICAgICAkKGUpLmNzcygnbWF4LWhlaWdodCcsIFwiY2FsYygxMDB2aCAtIFwiICsgdG9wICsgXCJweClcIik7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9LCAxMDApO1xuICAgICAgICB9KTtcbiAgICAgICAgJCgnI25leHQtZGF5JykuY2xpY2soZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgX3RoaXMuX3dhcmVob3VzZS5wcm9jZXNzRGF5KCk7XG4gICAgICAgICAgICBfdGhpcy5fZGF5cyArPSAxO1xuICAgICAgICAgICAgX3RoaXMudXBkYXRlKCk7XG4gICAgICAgIH0pO1xuICAgICAgICAkKCcjaW5jcmVhc2UtY2FwYWNpdHknKS5jbGljayhmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAoX3RoaXMuX21vbmV5ID49IF90aGlzLl93YXJlaG91c2UuY2VsbENvc3QpIHtcbiAgICAgICAgICAgICAgICBfdGhpcy5fbW9uZXkgLT0gX3RoaXMuX3dhcmVob3VzZS5jZWxsQ29zdDtcbiAgICAgICAgICAgICAgICBfdGhpcy5fd2FyZWhvdXNlLmNhcGFjaXR5ICs9IDE7XG4gICAgICAgICAgICAgICAgX3RoaXMudXBkYXRlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBhbGVydCgn0J3QtdGF0LLQsNGC0LDQtdGCINC00LXQvdC10LMnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgJChkb2N1bWVudCkub24oJ2NsaWNrJywgJy51c2UtcHJvdGVjdG9yJywgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgc2VsZi5fY2VsbElkeCA9ICskKHRoaXMpLmF0dHIoJ2RhdGEtaWQnKTtcbiAgICAgICAgICAgIHNlbGYuc2hvd1Byb3RlY3RvclNlbGVjdG9yKCk7XG4gICAgICAgIH0pO1xuICAgICAgICAkKGRvY3VtZW50KS5vbignY2xpY2snLCAnLnByb3RlY3Rvci1zZWxlY3QnLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgcHJvdGVjdG9ySWR4ID0gKyQodGhpcykuYXR0cignZGF0YS1pZCcpO1xuICAgICAgICAgICAgdmFyIHByb3RlY3RvciA9IHNlbGYuX3Byb3RlY3Rvck1hbmFnZXIucHJvdGVjdG9yc1twcm90ZWN0b3JJZHhdO1xuICAgICAgICAgICAgcHJvdGVjdG9yLnByb3RlY3Qoc2VsZi5fd2FyZWhvdXNlLmNlbGxzW3NlbGYuX2NlbGxJZHhdKTtcbiAgICAgICAgICAgIHNlbGYuX21vbmV5IC09IHByb3RlY3Rvci5jb3N0O1xuICAgICAgICAgICAgc2VsZi5oaWRlUHJvdGVjdG9yU2VsZWN0b3IoKTtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIDtcbiAgICAvL9C+0YLQutGA0YvRgtC40LUg0L7Qv9GA0LXQtNC10LvRkdC90L3QvtCz0L4g0Y3QutGA0LDQvdCwINC40LPRgNGLXG4gICAgR2FtZU1hbmFnZXIucHJvdG90eXBlLm9wZW5TY3JlZW4gPSBmdW5jdGlvbiAoc2NyZWVuKSB7XG4gICAgICAgIHRoaXMuX2FjdGl2ZVNjcmVlbi5mYWRlT3V0KDEwMCwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgc2NyZWVuLmZhZGVJbigxMDApO1xuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5fYWN0aXZlU2NyZWVuID0gc2NyZWVuO1xuICAgIH07XG4gICAgLy/QvtCx0L3QvtCy0LjRgtGMINCy0YHRkSDQstC40LfRg9Cw0LvRjNC90L7QtSDRgdC+0YHRgtC+0Y/QvdC40LVcbiAgICBHYW1lTWFuYWdlci5wcm90b3R5cGUudXBkYXRlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgJG1lc3NhZ2VzID0gJCgnI21lc3NhZ2VzJyk7XG4gICAgICAgICRtZXNzYWdlcy5odG1sKHRoaXMuX21lc3NhZ2VzVGVtcGxhdGUoeyBtZXNzYWdlOiB0aGlzLl9tZXNzYWdlcyB9KSk7XG4gICAgICAgICRtZXNzYWdlcy5zY3JvbGxUb3AoJG1lc3NhZ2VzWzBdLnNjcm9sbEhlaWdodCk7XG4gICAgICAgICQoJyNjZWxsLWNvc3QnKS50ZXh0KHRoaXMuX3dhcmVob3VzZS5jZWxsQ29zdCk7XG4gICAgICAgIHRoaXMudXBkYXRlSW5mbygpO1xuICAgICAgICB0aGlzLnVwZGF0ZUNlbGxzKCk7XG4gICAgICAgIHRoaXMuY2hlY2tMb3NlKCk7XG4gICAgfTtcbiAgICAvL9C/0YDQvtCy0LXRgNC40YLRjCDRg9GB0LvQvtCy0LjQtSDQv9GA0L7QuNCz0YDRi9GI0LBcbiAgICBHYW1lTWFuYWdlci5wcm90b3R5cGUuY2hlY2tMb3NlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICBpZiAodGhpcy5fbW9uZXkgPCAwKSB7XG4gICAgICAgICAgICB0aGlzLl9sb3NlTW9kYWwuZGlhbG9nKCdvcGVuJyk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIC8v0L/QvtC60LDQt9Cw0YLRjCDQvtC60L3QviDQstGL0LHQvtGA0LAg0YHRgNC10LTRgdGC0LIg0LfQsNGJ0LjRgtGLXG4gICAgR2FtZU1hbmFnZXIucHJvdG90eXBlLnNob3dQcm90ZWN0b3JTZWxlY3RvciA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIGJhZEZhY3RvciA9IHRoaXMuX3dhcmVob3VzZS5jZWxsc1t0aGlzLl9jZWxsSWR4XS5iYWRGYWN0b3I7XG4gICAgICAgIHZhciB0cGxQcm90ZWN0b3JzID0gW107XG4gICAgICAgIGlmIChiYWRGYWN0b3IpIHtcbiAgICAgICAgICAgIHZhciBpID0gMDtcbiAgICAgICAgICAgIGZvciAodmFyIF9pID0gMCwgX2EgPSB0aGlzLl9wcm90ZWN0b3JNYW5hZ2VyLnByb3RlY3RvcnM7IF9pIDwgX2EubGVuZ3RoOyBfaSsrKSB7XG4gICAgICAgICAgICAgICAgdmFyIHByb3RlY3RvciA9IF9hW19pXTtcbiAgICAgICAgICAgICAgICBpZiAocHJvdGVjdG9yLtGBYW5Qcm90ZWN0RnJvbShiYWRGYWN0b3IpKSB7XG4gICAgICAgICAgICAgICAgICAgIHRwbFByb3RlY3RvcnMucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYW46IHRoaXMuX21vbmV5ID49IHByb3RlY3Rvci5jb3N0LFxuICAgICAgICAgICAgICAgICAgICAgICAgcHJvdGVjdG9yOiBwcm90ZWN0b3IsXG4gICAgICAgICAgICAgICAgICAgICAgICBwcm90ZWN0b3JfaWQ6IGlcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICsraTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgICQoJyNwcm90ZWN0b3JzJykuaHRtbCh0aGlzLl9wcm90ZWN0b3JUZW1wbGF0ZSh7XG4gICAgICAgICAgICAgICAgcHJvdGVjdG9yczogdHBsUHJvdGVjdG9yc1xuICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgdGhpcy5fcHJvdGVjdG9yc01vZGFsLmRpYWxvZygnb3BlbicpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgYWxlcnQoJ9CX0LTQtdGB0Ywg0L3QtdGCINC/0LvQvtGF0LjRhSDRhNCw0LrRgtC+0YDQvtCyJyk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIC8v0LfQsNC60YDRi9GC0Ywg0L7QutC90L4g0LLRi9Cx0L7RgNCwINGB0YDQtdC00YHRgtCyINC30LDRidC40YLRi1xuICAgIEdhbWVNYW5hZ2VyLnByb3RvdHlwZS5oaWRlUHJvdGVjdG9yU2VsZWN0b3IgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHRoaXMuX3Byb3RlY3RvcnNNb2RhbC5kaWFsb2coJ2Nsb3NlJyk7XG4gICAgICAgIHRoaXMudXBkYXRlKCk7XG4gICAgfTtcbiAgICAvL9C+0LHQvdC+0LLQuNGC0Ywg0LjQvdGE0L7RgNC80LDRhtC40Y4g0LTQu9GPINC/0L7Qu9GM0LfQvtCy0LDRgtC10LvRj1xuICAgIEdhbWVNYW5hZ2VyLnByb3RvdHlwZS51cGRhdGVJbmZvID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAkKCcjdG9wLWluZm8nKS5odG1sKHRoaXMuX2luZm9UZW1wbGF0ZSh7XG4gICAgICAgICAgICBtb25leTogdGhpcy5fbW9uZXksXG4gICAgICAgICAgICBidXN5X2NlbGxzOiB0aGlzLl93YXJlaG91c2UuYnVzeUNlbGxzLFxuICAgICAgICAgICAgdG90YWxfY2VsbHM6IHRoaXMuX3dhcmVob3VzZS5jYXBhY2l0eSxcbiAgICAgICAgICAgIGNvcnJ1cHRlZENlbGxzOiB0aGlzLl93YXJlaG91c2UuY29ycnVwdGVkQ2VsbHMsXG4gICAgICAgICAgICBkYXlzOiB0aGlzLl9kYXlzXG4gICAgICAgIH0pKTtcbiAgICB9O1xuICAgIC8v0L7QsdC90L7QstC40YLRjCDRj9GH0LXQudC60LhcbiAgICBHYW1lTWFuYWdlci5wcm90b3R5cGUudXBkYXRlQ2VsbHMgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICQoJyNjZWxscycpLmh0bWwodGhpcy5fY2VsbFRlbXBsYXRlKHtcbiAgICAgICAgICAgIGNlbGxzOiB0aGlzLl93YXJlaG91c2UuY2VsbHNcbiAgICAgICAgfSkpO1xuICAgIH07XG4gICAgLy/QvtGC0L/RgNCw0LLQuNGC0Ywg0L/QvtC70YzQt9C+0LLQsNGC0LXQu9GOINGB0L7QvtCx0YnQtdC90LjQtVxuICAgIEdhbWVNYW5hZ2VyLnByb3RvdHlwZS5tZXNzYWdlID0gZnVuY3Rpb24gKG1zZykge1xuICAgICAgICB0aGlzLl9tZXNzYWdlcy5wdXNoKG1zZyk7XG4gICAgICAgIHRoaXMudXBkYXRlKCk7XG4gICAgfTtcbiAgICAvL9C90LDRh9Cw0YLRjCDRgdC70YPRiNCw0YLRjCDRgdC+0LHRi9GC0LjRjyDRgdC60LvQsNC00LBcbiAgICBHYW1lTWFuYWdlci5wcm90b3R5cGUuYXR0YWNoRXZlbnRIYW5kbGVycyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgdGhpcy5fd2FyZWhvdXNlLm9uKCdjZWxsLXJlbnQnLCBmdW5jdGlvbiAoY2VsbCwgcmVudCkge1xuICAgICAgICAgICAgX3RoaXMuX21vbmV5ICs9IHJlbnQ7XG4gICAgICAgICAgICB2YXIgY2VsbFF1YWxpdHkgPSBNYXRoLnJvdW5kKGNlbGwucmVzb3VyY2UucXVhbGl0eSAvIGNlbGwucmVzb3VyY2UuZGVzY3JpcHRpb24ucXVhbGl0eSAqIDEwMCk7XG4gICAgICAgICAgICBfdGhpcy5tZXNzYWdlKFwiXFx1MDQxMlxcdTA0NEIgXFx1MDQzRlxcdTA0M0VcXHUwNDNCXFx1MDQ0M1xcdTA0NDdcXHUwNDM4XFx1MDQzQlxcdTA0MzggPGI+XCIgKyByZW50ICsgXCJcXHUwNDQwXFx1MDQ0M1xcdTA0MzEuPC9iPiBcXHUwNDM3XFx1MDQzMCBcXHUwNDQ1XFx1MDQ0MFxcdTA0MzBcXHUwNDNEXFx1MDQzNVxcdTA0M0RcXHUwNDM4XFx1MDQzNVxcbiAgICAgICAgICAgIDxpPlwiICsgY2VsbC5yZXNvdXJjZS5kZXNjcmlwdGlvbi5uYW1lICsgXCI8L2k+IFxcdTA0NDEgXFx1MDQzQVxcdTA0MzBcXHUwNDQ3XFx1MDQzNVxcdTA0NDFcXHUwNDQyXFx1MDQzMlxcdTA0M0VcXHUwNDNDIDxiPlwiICsgY2VsbFF1YWxpdHkgKyBcIiU8L2I+XCIpO1xuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5fd2FyZWhvdXNlLm9uKCduZXctY2VsbCcsIGZ1bmN0aW9uIChjZWxsKSB7XG4gICAgICAgICAgICBfdGhpcy5tZXNzYWdlKFwiXFx1MDQxN1xcdTA0MzBcXHUwNDMyXFx1MDQzNVxcdTA0MzdcXHUwNDNCXFx1MDQzOCBcXHUwNDNEXFx1MDQzRVxcdTA0MzJcXHUwNDRCXFx1MDQzOSBcXHUwNDQyXFx1MDQzRVxcdTA0MzJcXHUwNDMwXFx1MDQ0MCA8Yj5cIiArIGNlbGwucmVzb3VyY2UuZGVzY3JpcHRpb24ubmFtZSArIFwiPC9iPlxcbiAgICAgICAgICAgIFxcdTA0M0RcXHUwNDMwIFxcdTA0NDFcXHUwNDQwXFx1MDQzRVxcdTA0M0EgPGI+XCIgKyBjZWxsLnN0b3JlRGF5cyArIFwiXFx1MDQzNFxcdTA0M0QuPC9iPlwiKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuX3dhcmVob3VzZS5vbignYmFkLWZhY3Rvci1zcHJlYWQnLCBmdW5jdGlvbiAoY2VsbCwgaSkge1xuICAgICAgICAgICAgX3RoaXMubWVzc2FnZShcIjxmb250IGNvbG9yPVxcXCIjYTUyYTJhXFxcIj5cXG4gICAgICAgICAgICBcXHUwNDFEXFx1MDQzMCBcXHUwNDNDXFx1MDQzNVxcdTA0NDFcXHUwNDQyXFx1MDQzNSA8Yj5cXHUyMTE2XCIgKyBpICsgXCI8L2I+IFxcdTA0M0ZcXHUwNDNFXFx1MDQ0RlxcdTA0MzJcXHUwNDM4XFx1MDQzQlxcdTA0M0VcXHUwNDQxXFx1MDQ0QyA8Yj5cIiArIGNlbGwuYmFkRmFjdG9yLmRlc2NyaXB0aW9uLm5hbWUgKyBcIjwvYj5cXG4gICAgICAgICAgICA8L2ZvbnQ+XCIpO1xuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5fd2FyZWhvdXNlLm9uKCdjZWxsLXJlc291cmNlLWRlc3Ryb3llZCcsIGZ1bmN0aW9uIChjZWxsLCBwZW5hbHR5LCBpKSB7XG4gICAgICAgICAgICAvL9C/0L7Qu9GD0YfQsNC10Lwg0YjRgtGA0LDRhFxuICAgICAgICAgICAgX3RoaXMuX21vbmV5IC09IHBlbmFsdHk7XG4gICAgICAgICAgICBfdGhpcy5tZXNzYWdlKFwiPGZvbnQgY29sb3I9XFxcIiNhNTJhMmFcXFwiPlxcbiAgICAgICAgICAgIFxcdTA0MjJcXHUwNDNFXFx1MDQzMlxcdTA0MzBcXHUwNDQwIFxcdTA0M0RcXHUwNDMwIFxcdTA0M0NcXHUwNDM1XFx1MDQ0MVxcdTA0NDJcXHUwNDM1IDxiPlxcdTIxMTZcIiArIGkgKyBcIjwvYj4gXFx1MDQzMVxcdTA0NEJcXHUwNDNCIFxcdTA0NDNcXHUwNDNEXFx1MDQzOFxcdTA0NDdcXHUwNDQyXFx1MDQzRVxcdTA0MzZcXHUwNDM1XFx1MDQzRCBcXHUwNDM4XFx1MDQzNy1cXHUwNDM3XFx1MDQzMCA8Yj5cIiArIGNlbGwuYmFkRmFjdG9yLmRlc2NyaXB0aW9uLm5hbWUgKyBcIjwvYj4uPGJyLz5cXG4gICAgICAgICAgICBcXHUwNDExXFx1MDQ0QlxcdTA0M0JcXHUwNDNFIFxcdTA0M0ZcXHUwNDNFXFx1MDQ0MlxcdTA0MzVcXHUwNDQwXFx1MDQ0RlxcdTA0M0RcXHUwNDNFIDxiPlwiICsgcGVuYWx0eSArIFwiXFx1MDQ0MFxcdTA0NDNcXHUwNDMxLjwvYj5cXG4gICAgICAgICAgICA8L2ZvbnQ+XCIpO1xuICAgICAgICB9KTtcbiAgICB9O1xuICAgIC8v0L3QsNGH0LDRgtGMINC40LPRgNGDOiDQuNC90LjRhtC40LDQu9GM0LfQuNGA0L7QstCw0YLRjCDQvdGD0LbQvdGL0LUg0L/QtdGA0LXQvNC10L3QvdGL0LVcbiAgICBHYW1lTWFuYWdlci5wcm90b3R5cGUuc3RhcnRHYW1lID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB0aGlzLl9tZXNzYWdlcyA9IFtdO1xuICAgICAgICB0aGlzLl9tb25leSA9IDI1MDtcbiAgICAgICAgdGhpcy5fZGF5cyA9IDA7XG4gICAgICAgIHRoaXMuX3dhcmVob3VzZSA9IG5ldyBXYXJlaG91c2VfMS5XYXJlaG91c2UodGhpcy5fcmVzb3VyY2VNYW5hZ2VyLnJlc291cmNlcywgdGhpcy5fYmFkRmFjdG9yTWFuYWdlci5iYWRGYWN0b3JzKTtcbiAgICAgICAgdGhpcy5hdHRhY2hFdmVudEhhbmRsZXJzKCk7XG4gICAgICAgIHRoaXMudXBkYXRlKCk7XG4gICAgfTtcbiAgICByZXR1cm4gR2FtZU1hbmFnZXI7XG59KCkpO1xuZXhwb3J0cy5HYW1lTWFuYWdlciA9IEdhbWVNYW5hZ2VyO1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG4vL9Ch0YDQtdC00YHRgtCy0L4g0LfQsNGJ0LjRgtGLINC+0YIg0L/Qu9C+0YXQvtCz0L4g0YTQsNC60YLQvtGA0LBcbnZhciBQcm90ZWN0b3IgPSAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIFByb3RlY3RvcihuYW1lLCBjb3N0LCBkYW1hZ2UsIGdvb2RBZ2FpbnN0KSB7XG4gICAgICAgIHRoaXMuX25hbWUgPSBuYW1lO1xuICAgICAgICB0aGlzLl9jb3N0ID0gY29zdDtcbiAgICAgICAgdGhpcy5fZGFtYWdlID0gZGFtYWdlO1xuICAgICAgICB0aGlzLl9nb29kQWdhaW5zdCA9IGdvb2RBZ2FpbnN0O1xuICAgIH1cbiAgICAvL9Cf0YDQvtCy0LXRgNC60LAsINC80L7QttC10YIg0LvQuCDQtNCw0L3QvdC+0LUg0YHRgNC10LTRgdGC0LLQviDRgdC/0YDQsNCy0LjRgtGM0YHRjyDRgSDQvtC/0YDQtdC00LXQu9GR0L3QvdGL0Lwg0YTQsNC60YLQvtGA0L7QvFxuICAgIFByb3RlY3Rvci5wcm90b3R5cGUu0YFhblByb3RlY3RGcm9tID0gZnVuY3Rpb24gKGJhZEZhY3Rvcikge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ29vZEFnYWluc3QuaW5kZXhPZihiYWRGYWN0b3IuZGVzY3JpcHRpb24pICE9PSAtMTtcbiAgICB9O1xuICAgIC8v0JfQsNGJ0LjRgtCwINC+0YIg0YTQsNC60YLQvtGA0LBcbiAgICBQcm90ZWN0b3IucHJvdG90eXBlLnByb3RlY3QgPSBmdW5jdGlvbiAoY2VsbCkge1xuICAgICAgICBpZiAodGhpcy7RgWFuUHJvdGVjdEZyb20oY2VsbC5iYWRGYWN0b3IpKSB7XG4gICAgICAgICAgICBjZWxsLmJhZEZhY3Rvci5oaXRQb2ludHMgLT0gdGhpcy5fZGFtYWdlO1xuICAgICAgICAgICAgaWYgKGNlbGwuYmFkRmFjdG9yLmhpdFBvaW50cyA8PSAwKSB7XG4gICAgICAgICAgICAgICAgY2VsbC5iYWRGYWN0b3IgPSBudWxsO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoUHJvdGVjdG9yLnByb3RvdHlwZSwgXCJjb3N0XCIsIHtcbiAgICAgICAgLy/QktC+0LfQstGA0LDRidCw0LXRgiDRgdGC0L7QuNC80L7RgdGC0Ywg0YHRgNC10LTRgdGC0LLQsFxuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9jb3N0O1xuICAgICAgICB9LFxuICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9KTtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoUHJvdGVjdG9yLnByb3RvdHlwZSwgXCJkYW1hZ2VcIiwge1xuICAgICAgICAvL9CS0L7Qt9Cy0YDQsNGJ0LDQtdGCINGD0YDQvtC9INC/0LvQvtGF0L7QvNGDINGE0LDQutGC0L7RgNGDXG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2RhbWFnZTtcbiAgICAgICAgfSxcbiAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSk7XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KFByb3RlY3Rvci5wcm90b3R5cGUsIFwibmFtZVwiLCB7XG4gICAgICAgIC8v0JLQvtC30LLRgNCw0YnQsNC10YIg0L3QsNC30LLQsNC90LjQtSDRgdGA0LXQtNGB0YLQstCwXG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX25hbWU7XG4gICAgICAgIH0sXG4gICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0pO1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShQcm90ZWN0b3IucHJvdG90eXBlLCBcImdvb2RBZ2FpbnN0XCIsIHtcbiAgICAgICAgLy/QktC+0LfQstGA0LDRidCw0LXRgiDQv9C70L7RhdC40LUg0YTQsNC60YLQvtGA0YssINC/0YDQvtGC0LjQsiDQutC+0YLQvtGA0YvRhSDQtNCw0L3QvdC+0LUg0YHRgNC10LTRgdGC0LLQviDRgNCw0LHQvtGC0LXRglxuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9nb29kQWdhaW5zdDtcbiAgICAgICAgfSxcbiAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSk7XG4gICAgcmV0dXJuIFByb3RlY3Rvcjtcbn0oKSk7XG5leHBvcnRzLlByb3RlY3RvciA9IFByb3RlY3RvcjtcbiIsIlwidXNlIHN0cmljdFwiO1xudmFyIF9fZXh0ZW5kcyA9ICh0aGlzICYmIHRoaXMuX19leHRlbmRzKSB8fCBmdW5jdGlvbiAoZCwgYikge1xuICAgIGZvciAodmFyIHAgaW4gYikgaWYgKGIuaGFzT3duUHJvcGVydHkocCkpIGRbcF0gPSBiW3BdO1xuICAgIGZ1bmN0aW9uIF9fKCkgeyB0aGlzLmNvbnN0cnVjdG9yID0gZDsgfVxuICAgIGQucHJvdG90eXBlID0gYiA9PT0gbnVsbCA/IE9iamVjdC5jcmVhdGUoYikgOiAoX18ucHJvdG90eXBlID0gYi5wcm90b3R5cGUsIG5ldyBfXygpKTtcbn07XG52YXIgdXRpbF8xID0gcmVxdWlyZShcIi4vdXRpbFwiKTtcbnZhciBVc2VyVmFsdWVzTWFuYWdlcl8xID0gcmVxdWlyZShcIi4vVXNlclZhbHVlc01hbmFnZXJcIik7XG52YXIgUHJvdGVjdG9yXzEgPSByZXF1aXJlKFwiLi9Qcm90ZWN0b3JcIik7XG4vL9Cj0L/RgNCw0LLQu9C10L3QuNC1INGB0L/QuNGB0LrQvtC8INGB0YDQtdC00YHRgtCyINC30LDRidC40YLRi1xudmFyIFByb3RlY3Rvck1hbmFnZXIgPSAoZnVuY3Rpb24gKF9zdXBlcikge1xuICAgIF9fZXh0ZW5kcyhQcm90ZWN0b3JNYW5hZ2VyLCBfc3VwZXIpO1xuICAgIGZ1bmN0aW9uIFByb3RlY3Rvck1hbmFnZXIoYmFkRmFjdG9ycykge1xuICAgICAgICBfc3VwZXIuY2FsbCh0aGlzLCBiYWRGYWN0b3JzKTtcbiAgICAgICAgdGhpcy5fZW50aXRpZXMucHVzaChuZXcgUHJvdGVjdG9yXzEuUHJvdGVjdG9yKCfQntGC0YDQsNCy0LAnLCA1MCwgMjAsIHV0aWxfMS5zZWxlY3RJbmRleGVzKGJhZEZhY3RvcnMsIFswLCAxXSkpKTtcbiAgICAgICAgdGhpcy5fZW50aXRpZXMucHVzaChuZXcgUHJvdGVjdG9yXzEuUHJvdGVjdG9yKCfQmNC90YHQtdC60YLQuNGG0LjQtNGLJywgMjUsIDQ1LCB1dGlsXzEuc2VsZWN0SW5kZXhlcyhiYWRGYWN0b3JzLCBbMV0pKSk7XG4gICAgICAgIHRoaXMuX2VudGl0aWVzLnB1c2gobmV3IFByb3RlY3Rvcl8xLlByb3RlY3Rvcign0JLQvtC00LAnLCAzMCwgMjAsIHV0aWxfMS5zZWxlY3RJbmRleGVzKGJhZEZhY3RvcnMsIFswLCAyXSkpKTtcbiAgICAgICAgdGhpcy5fZW50aXRpZXMucHVzaChuZXcgUHJvdGVjdG9yXzEuUHJvdGVjdG9yKCfQntCz0L3QtdGC0YPRiNC40YLQtdC70YwnLCA2MCwgNTAsIHV0aWxfMS5zZWxlY3RJbmRleGVzKGJhZEZhY3RvcnMsIFsyXSkpKTtcbiAgICAgICAgdGhpcy5fZW50aXRpZXMucHVzaChuZXcgUHJvdGVjdG9yXzEuUHJvdGVjdG9yKCfQodC40LvQuNC60LDQs9C10LvRjCcsIDE1MCwgNTAsIHV0aWxfMS5zZWxlY3RJbmRleGVzKGJhZEZhY3RvcnMsIFswLCAxLCAzXSkpKTtcbiAgICAgICAgdGhpcy5fZW50aXRpZXMucHVzaChuZXcgUHJvdGVjdG9yXzEuUHJvdGVjdG9yKCfQktC70LDQs9C+0L/QvtCz0LvQvtGC0LjRgtC10LvRjCcsIDUwLCA0MCwgdXRpbF8xLnNlbGVjdEluZGV4ZXMoYmFkRmFjdG9ycywgWzNdKSkpO1xuICAgICAgICB0aGlzLnJlbmRlckxpc3QoKTtcbiAgICB9XG4gICAgUHJvdGVjdG9yTWFuYWdlci5wcm90b3R5cGUuZ2V0RW50aXR5TmFtZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuICdwcm90ZWN0b3InO1xuICAgIH07XG4gICAgUHJvdGVjdG9yTWFuYWdlci5wcm90b3R5cGUuZ2V0Rm9ybVdpZHRoID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gNDUwO1xuICAgIH07XG4gICAgUHJvdGVjdG9yTWFuYWdlci5wcm90b3R5cGUuZ2V0Rm9ybUhlaWdodCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIDU1MDtcbiAgICB9O1xuICAgIFByb3RlY3Rvck1hbmFnZXIucHJvdG90eXBlLmdldE11bHRpT2JqZWN0cyA9IGZ1bmN0aW9uIChwcm90ZWN0b3IpIHtcbiAgICAgICAgcmV0dXJuIHByb3RlY3Rvci5nb29kQWdhaW5zdDtcbiAgICB9O1xuICAgIFByb3RlY3Rvck1hbmFnZXIucHJvdG90eXBlLmNyZWF0ZUVudGl0eSA9IGZ1bmN0aW9uIChmb3JtRGF0YSkge1xuICAgICAgICB2YXIgYmFkRmFjdG9yQXJyYXkgPSB0aGlzLmdldE11bHRpU2VsZWN0ZWRPYmplY3RzKGZvcm1EYXRhKTtcbiAgICAgICAgcmV0dXJuIG5ldyBQcm90ZWN0b3JfMS5Qcm90ZWN0b3IoZm9ybURhdGEubmFtZSwgZm9ybURhdGEuY29zdCB8fCAxLCBmb3JtRGF0YS5kYW1hZ2UgfHwgMTAsIGJhZEZhY3RvckFycmF5KTtcbiAgICB9O1xuICAgIFByb3RlY3Rvck1hbmFnZXIucHJvdG90eXBlLnNldEZvcm1WYWx1ZXMgPSBmdW5jdGlvbiAocHJvdGVjdG9yKSB7XG4gICAgICAgIHRoaXMuX2Zvcm0uZmluZCgnW25hbWU9XCJuYW1lXCJdJykudmFsKHByb3RlY3Rvci5uYW1lKTtcbiAgICAgICAgdGhpcy5fZm9ybS5maW5kKCdbbmFtZT1cImNvc3RcIl0nKS52YWwocHJvdGVjdG9yLmNvc3QpO1xuICAgICAgICB0aGlzLl9mb3JtLmZpbmQoJ1tuYW1lPVwiZGFtYWdlXCJdJykudmFsKHByb3RlY3Rvci5kYW1hZ2UpO1xuICAgIH07XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KFByb3RlY3Rvck1hbmFnZXIucHJvdG90eXBlLCBcInByb3RlY3RvcnNcIiwge1xuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9lbnRpdGllcztcbiAgICAgICAgfSxcbiAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSk7XG4gICAgcmV0dXJuIFByb3RlY3Rvck1hbmFnZXI7XG59KFVzZXJWYWx1ZXNNYW5hZ2VyXzEuVXNlclZhbHVlc01hbmFnZXIpKTtcbmV4cG9ydHMuUHJvdGVjdG9yTWFuYWdlciA9IFByb3RlY3Rvck1hbmFnZXI7XG4iLCJcInVzZSBzdHJpY3RcIjtcbi8v0JrQvtC90LrRgNC10YLQvdGL0Lkg0YDQtdGB0YPRgNGBLCDQutC+0YLQvtGA0YvQuSDRhdGA0LDQvdC40YLRgdGPINC90LAg0YHQutC70LDQtNC1XG52YXIgUmVzb3VyY2UgPSAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIFJlc291cmNlKGRlc2NyaXB0aW9uKSB7XG4gICAgICAgIHRoaXMuX2Rlc2NyaXB0aW9uID0gZGVzY3JpcHRpb247XG4gICAgICAgIHRoaXMuX3F1YWxpdHkgPSBkZXNjcmlwdGlvbi5xdWFsaXR5O1xuICAgIH1cbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoUmVzb3VyY2UucHJvdG90eXBlLCBcImRlc2NyaXB0aW9uXCIsIHtcbiAgICAgICAgLy/QktC+0LfQstGA0LDRidCw0LXRgiDRgdCy0L7QudGB0YLQstCwINGA0LXRgdGD0YDRgdCwXG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2Rlc2NyaXB0aW9uO1xuICAgICAgICB9LFxuICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9KTtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoUmVzb3VyY2UucHJvdG90eXBlLCBcInF1YWxpdHlcIiwge1xuICAgICAgICAvL9CS0L7Qt9Cy0YDQsNGJ0LDQtdGCINC60LDRh9C10YHRgtCy0L4g0YDQtdGB0YPRgNGB0LBcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fcXVhbGl0eTtcbiAgICAgICAgfSxcbiAgICAgICAgLy/Qo9GB0YLQsNC90LDQstC70LjQstCw0LXRgiDQutCw0YfQtdGB0YLQstC+INGA0LXRgdGD0YDRgdCwXG4gICAgICAgIHNldDogZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICB0aGlzLl9xdWFsaXR5ID0gdmFsdWU7XG4gICAgICAgIH0sXG4gICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0pO1xuICAgIHJldHVybiBSZXNvdXJjZTtcbn0oKSk7XG5leHBvcnRzLlJlc291cmNlID0gUmVzb3VyY2U7XG4iLCJcInVzZSBzdHJpY3RcIjtcbi8v0J7Qv9C40YHQsNC90LjQtSDRgdCy0L7QudGB0YLQsiDRgNC10YHRg9GA0YHQsFxudmFyIFJlc291cmNlRGVzY3JpcHRpb24gPSAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIFJlc291cmNlRGVzY3JpcHRpb24obmFtZSwgcXVhbGl0eSwgcmVudCwgaW1hZ2UpIHtcbiAgICAgICAgLy/QuNC30L7QsdGA0LDQttC10L3QuNC1XG4gICAgICAgIHRoaXMuX2ltYWdlVXJsID0gbnVsbDtcbiAgICAgICAgdGhpcy5fbmFtZSA9IG5hbWU7XG4gICAgICAgIHRoaXMuX3F1YWxpdHkgPSBxdWFsaXR5O1xuICAgICAgICB0aGlzLl9yZW50ID0gcmVudDtcbiAgICAgICAgaWYgKGltYWdlKSB7XG4gICAgICAgICAgICB0aGlzLl9pbWFnZVVybCA9IGltYWdlO1xuICAgICAgICB9XG4gICAgfVxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShSZXNvdXJjZURlc2NyaXB0aW9uLnByb3RvdHlwZSwgXCJuYW1lXCIsIHtcbiAgICAgICAgLy/QktC+0LfRgNCw0YnQsNC10YIg0L3QsNC30LLQsNC90LjQtSDRgNC10YHRg9GA0YHQsFxuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9uYW1lO1xuICAgICAgICB9LFxuICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9KTtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoUmVzb3VyY2VEZXNjcmlwdGlvbi5wcm90b3R5cGUsIFwicXVhbGl0eVwiLCB7XG4gICAgICAgIC8v0JLQvtC30LLRgNCw0YnQsNC10YIg0LrQsNGH0LXRgdGC0LLQviDRgNC10YHRg9GA0YHQsFxuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9xdWFsaXR5O1xuICAgICAgICB9LFxuICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9KTtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoUmVzb3VyY2VEZXNjcmlwdGlvbi5wcm90b3R5cGUsIFwicmVudFwiLCB7XG4gICAgICAgIC8v0JLQvtC30LLRgNCw0YnQsNC10YIg0LrQvtC70LjRh9C10YHRgtCy0L4g0LTQtdC90LXQsyDQt9CwINCw0YDQtdC90LTRg1xuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9yZW50O1xuICAgICAgICB9LFxuICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9KTtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoUmVzb3VyY2VEZXNjcmlwdGlvbi5wcm90b3R5cGUsIFwiaW1hZ2VcIiwge1xuICAgICAgICAvL9CS0L7Qt9Cy0YDQsNGJ0LDQtdGCIHVybCDQuNC30L7QsdGA0LDQttC10L3QuNGPXG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2ltYWdlVXJsO1xuICAgICAgICB9LFxuICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9KTtcbiAgICByZXR1cm4gUmVzb3VyY2VEZXNjcmlwdGlvbjtcbn0oKSk7XG5leHBvcnRzLlJlc291cmNlRGVzY3JpcHRpb24gPSBSZXNvdXJjZURlc2NyaXB0aW9uO1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG52YXIgX19leHRlbmRzID0gKHRoaXMgJiYgdGhpcy5fX2V4dGVuZHMpIHx8IGZ1bmN0aW9uIChkLCBiKSB7XG4gICAgZm9yICh2YXIgcCBpbiBiKSBpZiAoYi5oYXNPd25Qcm9wZXJ0eShwKSkgZFtwXSA9IGJbcF07XG4gICAgZnVuY3Rpb24gX18oKSB7IHRoaXMuY29uc3RydWN0b3IgPSBkOyB9XG4gICAgZC5wcm90b3R5cGUgPSBiID09PSBudWxsID8gT2JqZWN0LmNyZWF0ZShiKSA6IChfXy5wcm90b3R5cGUgPSBiLnByb3RvdHlwZSwgbmV3IF9fKCkpO1xufTtcbnZhciBSZXNvdXJjZURlc2NyaXB0aW9uXzEgPSByZXF1aXJlKFwiLi9SZXNvdXJjZURlc2NyaXB0aW9uXCIpO1xudmFyIFVzZXJWYWx1ZXNNYW5hZ2VyXzEgPSByZXF1aXJlKFwiLi9Vc2VyVmFsdWVzTWFuYWdlclwiKTtcbi8v0KPQv9GA0LDQstC70LXQvdC40LUg0YHQv9C40YHQutC+0Lwg0YDQtdGB0YPRgNGB0L7QslxudmFyIFJlc291cmNlTWFuYWdlciA9IChmdW5jdGlvbiAoX3N1cGVyKSB7XG4gICAgX19leHRlbmRzKFJlc291cmNlTWFuYWdlciwgX3N1cGVyKTtcbiAgICBmdW5jdGlvbiBSZXNvdXJjZU1hbmFnZXIoKSB7XG4gICAgICAgIF9zdXBlci5jYWxsKHRoaXMpO1xuICAgICAgICB0aGlzLl9lbnRpdGllcy5wdXNoKG5ldyBSZXNvdXJjZURlc2NyaXB0aW9uXzEuUmVzb3VyY2VEZXNjcmlwdGlvbign0KHQtdC90L4nLCAxMDAsIDEwMCwgJy9pbWcvc2Vuby5qcGcnKSk7XG4gICAgICAgIHRoaXMuX2VudGl0aWVzLnB1c2gobmV3IFJlc291cmNlRGVzY3JpcHRpb25fMS5SZXNvdXJjZURlc2NyaXB0aW9uKCfQnNGL0LvQvicsIDEzMCwgNzAsICcvaW1nL215bG8uanBnJykpO1xuICAgICAgICB0aGlzLl9lbnRpdGllcy5wdXNoKG5ldyBSZXNvdXJjZURlc2NyaXB0aW9uXzEuUmVzb3VyY2VEZXNjcmlwdGlvbign0KXQu9C10LEnLCAzMCwgMTMwLCAnL2ltZy9obGViLmpwZycpKTtcbiAgICAgICAgdGhpcy5fZW50aXRpZXMucHVzaChuZXcgUmVzb3VyY2VEZXNjcmlwdGlvbl8xLlJlc291cmNlRGVzY3JpcHRpb24oJ9CS0L7QtNCwJywgMjAsIDEwMCwgJy9pbWcvdm9kYS5qcGcnKSk7XG4gICAgICAgIHRoaXMuX2VudGl0aWVzLnB1c2gobmV3IFJlc291cmNlRGVzY3JpcHRpb25fMS5SZXNvdXJjZURlc2NyaXB0aW9uKCfQkdC10L3Qt9C40L0nLCAxMCwgMjAwLCAnL2ltZy9iZW56aW4ucG5nJykpO1xuICAgICAgICB0aGlzLl9lbnRpdGllcy5wdXNoKG5ldyBSZXNvdXJjZURlc2NyaXB0aW9uXzEuUmVzb3VyY2VEZXNjcmlwdGlvbign0KHQsNC70L4nLCA1MCwgMzAwLCAnL2ltZy9zYWxvLmpwZycpKTtcbiAgICAgICAgdGhpcy5fZW50aXRpZXMucHVzaChuZXcgUmVzb3VyY2VEZXNjcmlwdGlvbl8xLlJlc291cmNlRGVzY3JpcHRpb24oJ9CR0LXRgtC+0L0nLCAxMjAsIDYwLCAnL2ltZy9iZXRvbi5wbmcnKSk7XG4gICAgICAgIHRoaXMuX2VudGl0aWVzLnB1c2gobmV3IFJlc291cmNlRGVzY3JpcHRpb25fMS5SZXNvdXJjZURlc2NyaXB0aW9uKCfQmtC40YDQv9C40YcnLCAxMjAsIDMwLCAnL2ltZy9raXJwaXRjaC5qcGcnKSk7XG4gICAgICAgIHRoaXMuX2VudGl0aWVzLnB1c2gobmV3IFJlc291cmNlRGVzY3JpcHRpb25fMS5SZXNvdXJjZURlc2NyaXB0aW9uKCfQodCw0YXQsNGAJywgMzAsIDE0MCwgJy9pbWcvc2FoYXIuanBnJykpO1xuICAgICAgICB0aGlzLl9lbnRpdGllcy5wdXNoKG5ldyBSZXNvdXJjZURlc2NyaXB0aW9uXzEuUmVzb3VyY2VEZXNjcmlwdGlvbign0J/QvtGA0L7RhScsIDEwLCAxNjAsICcvaW1nL3Bvcm9oLnBuZycpKTtcbiAgICAgICAgdGhpcy5yZW5kZXJMaXN0KCk7XG4gICAgfVxuICAgIFJlc291cmNlTWFuYWdlci5wcm90b3R5cGUuZ2V0RW50aXR5TmFtZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuICdyZXNvdXJjZSc7XG4gICAgfTtcbiAgICBSZXNvdXJjZU1hbmFnZXIucHJvdG90eXBlLmdldEZvcm1XaWR0aCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIDQ1MDtcbiAgICB9O1xuICAgIFJlc291cmNlTWFuYWdlci5wcm90b3R5cGUuZ2V0Rm9ybUhlaWdodCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIDUwMDtcbiAgICB9O1xuICAgIFJlc291cmNlTWFuYWdlci5wcm90b3R5cGUuZ2V0TXVsdGlPYmplY3RzID0gZnVuY3Rpb24gKHJlc291cmNlKSB7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9O1xuICAgIFJlc291cmNlTWFuYWdlci5wcm90b3R5cGUuY3JlYXRlRW50aXR5ID0gZnVuY3Rpb24gKGZvcm1EYXRhKSB7XG4gICAgICAgIHJldHVybiBuZXcgUmVzb3VyY2VEZXNjcmlwdGlvbl8xLlJlc291cmNlRGVzY3JpcHRpb24oZm9ybURhdGEubmFtZSwgZm9ybURhdGEucXVhbGl0eSB8fCAxMDAsIGZvcm1EYXRhLnJlbnQgfHwgMTAwLCBmb3JtRGF0YS5pbWFnZSB8fCBudWxsKTtcbiAgICB9O1xuICAgIFJlc291cmNlTWFuYWdlci5wcm90b3R5cGUuc2V0Rm9ybVZhbHVlcyA9IGZ1bmN0aW9uIChyZXNvdXJjZSkge1xuICAgICAgICB0aGlzLl9mb3JtLmZpbmQoJ1tuYW1lPVwibmFtZVwiXScpLnZhbChyZXNvdXJjZS5uYW1lKTtcbiAgICAgICAgdGhpcy5fZm9ybS5maW5kKCdbbmFtZT1cInF1YWxpdHlcIl0nKS52YWwocmVzb3VyY2UucXVhbGl0eSk7XG4gICAgICAgIHRoaXMuX2Zvcm0uZmluZCgnW25hbWU9XCJyZW50XCJdJykudmFsKHJlc291cmNlLnJlbnQpO1xuICAgICAgICB0aGlzLl9mb3JtLmZpbmQoJ1tuYW1lPVwiaW1hZ2VcIl0nKS52YWwocmVzb3VyY2UuaW1hZ2UpO1xuICAgIH07XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KFJlc291cmNlTWFuYWdlci5wcm90b3R5cGUsIFwicmVzb3VyY2VzXCIsIHtcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fZW50aXRpZXM7XG4gICAgICAgIH0sXG4gICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0pO1xuICAgIHJldHVybiBSZXNvdXJjZU1hbmFnZXI7XG59KFVzZXJWYWx1ZXNNYW5hZ2VyXzEuVXNlclZhbHVlc01hbmFnZXIpKTtcbmV4cG9ydHMuUmVzb3VyY2VNYW5hZ2VyID0gUmVzb3VyY2VNYW5hZ2VyO1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG4vL9Ce0LHRidC40Lkg0LrQu9Cw0YHRgSDQtNC70Y8g0YLQtdGFINCy0LXRidC10Lkg0LrQvtGC0L7RgNGL0LUg0L/QvtC70YzQt9C+0LLQsNGC0LXQu9GMINC00L7QsdCw0LLQu9GP0LXRgi/QuNC30LzQtdC90Y/QtdGCL9GD0LTQsNC70Y/QtdGCXG52YXIgVXNlclZhbHVlc01hbmFnZXIgPSAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIFVzZXJWYWx1ZXNNYW5hZ2VyKG11bHRpT2JqZWN0cykge1xuICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAvL9C40L3QtNC10LrRgSDQvtCx0L3QvtCy0LvRj9C10LzQvtCz0L4g0Y3Qu9C10LzQtdC90YLQsFxuICAgICAgICB0aGlzLl91cGRhdGVJbmRleCA9IC0xO1xuICAgICAgICAvL9GB0L/QuNGB0L7QuiDQsiDQv9Cw0LzRj9GC0LhcbiAgICAgICAgdGhpcy5fZW50aXRpZXMgPSBbXTtcbiAgICAgICAgLy/RjdC70LXQvNC10L3RgiDQvNGD0LvRjNGC0LjQstGL0LHQvtGA0LBcbiAgICAgICAgdGhpcy5fbXVsdGlTZWxlY3QgPSBudWxsO1xuICAgICAgICAvL9C+0LHRitC10LrRgtGLINC00LvRjyDQvNGD0LvRjNGC0LjQstGL0LHQvtGA0LBcbiAgICAgICAgdGhpcy5fbXVsdGlPYmplY3RzID0gbnVsbDtcbiAgICAgICAgdGhpcy5fbW9kYWwgPSAkKHRoaXMuZ2V0Rm9ybUlkKCkpLmRpYWxvZyh7XG4gICAgICAgICAgICBhdXRvT3BlbjogZmFsc2UsXG4gICAgICAgICAgICBoZWlnaHQ6IHRoaXMuZ2V0Rm9ybUhlaWdodCgpLFxuICAgICAgICAgICAgd2lkdGg6IHRoaXMuZ2V0Rm9ybVdpZHRoKCksXG4gICAgICAgICAgICBtb2RhbDogdHJ1ZSxcbiAgICAgICAgICAgIGJ1dHRvbnM6IHtcbiAgICAgICAgICAgICAgICAn0J/RgNC40LzQtdC90LjRgtGMJzogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBfdGhpcy5zYXZlRm9ybSgpO1xuICAgICAgICAgICAgICAgICAgICBfdGhpcy5jbG9zZUZvcm0oKTtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICfQntGC0LzQtdC90LAnOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIF90aGlzLmNsb3NlRm9ybSgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBjbG9zZTogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIF90aGlzLl9mb3JtLmdldCgwKS5yZXNldCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5fZm9ybSA9IHRoaXMuX21vZGFsLmZpbmQoJ2Zvcm0nKTtcbiAgICAgICAgdGhpcy5fbGlzdFRlbXBsYXRlID0gSGFuZGxlYmFycy5jb21waWxlKCQodGhpcy5nZXRUZW1wbGF0ZUlkKCkpLmh0bWwoKSk7XG4gICAgICAgIHRoaXMuX2xpc3QgPSAkKHRoaXMuZ2V0TGlzdElkKCkpO1xuICAgICAgICB0aGlzLnJlbmRlckxpc3QoKTtcbiAgICAgICAgaWYgKG11bHRpT2JqZWN0cykge1xuICAgICAgICAgICAgdGhpcy5fbXVsdGlPYmplY3RzID0gbXVsdGlPYmplY3RzO1xuICAgICAgICAgICAgdGhpcy5fbXVsdGlTZWxlY3QgPSB0aGlzLl9mb3JtLmZpbmQoJ1tuYW1lPVwibXVsdGlcIl0nKTtcbiAgICAgICAgICAgIHRoaXMuX211bHRpU2VsZWN0Lm11bHRpU2VsZWN0KCk7XG4gICAgICAgICAgICB0aGlzLnVwZGF0ZVJlc291cmNlc0xpc3QoKTtcbiAgICAgICAgfVxuICAgICAgICAkKHRoaXMuZ2V0Q3JlYXRlQnRuSWQoKSkuY2xpY2soZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgX3RoaXMub3BlbkZvcm0oKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgJChkb2N1bWVudCkub24oJ2NsaWNrJywgdGhpcy5nZXREZWxldGVCdG5DbGFzcygpLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBzZWxmLmRlbGV0ZUVudGl0eSgrJCh0aGlzKS5wYXJlbnQoKS5hdHRyKCdkYXRhLWlkeCcpKTtcbiAgICAgICAgfSk7XG4gICAgICAgICQoZG9jdW1lbnQpLm9uKCdjbGljaycsIHRoaXMuZ2V0VXBkYXRlQnRuQ2xhc3MoKSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgc2VsZi51cGRhdGVFbnRpdHkoKyQodGhpcykucGFyZW50KCkuYXR0cignZGF0YS1pZHgnKSk7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvL9C/0L7Qu9GD0YfQuNGC0YwgaWQg0YjQsNCx0LvQvtC90LAg0YHRg9GJ0L3QvtGB0YLQuFxuICAgIFVzZXJWYWx1ZXNNYW5hZ2VyLnByb3RvdHlwZS5nZXRUZW1wbGF0ZUlkID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gXCIjXCIgKyB0aGlzLmdldEVudGl0eU5hbWUoKSArIFwiLXRlbXBsYXRlXCI7XG4gICAgfTtcbiAgICAvL9C/0L7Qu9GD0YfQuNGC0YwgaWQg0YHQv9C40YHQutCwINGB0YPRidC90L7RgdGC0LhcbiAgICBVc2VyVmFsdWVzTWFuYWdlci5wcm90b3R5cGUuZ2V0TGlzdElkID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gXCIjXCIgKyB0aGlzLmdldEVudGl0eU5hbWUoKSArIFwiLWxpc3RcIjtcbiAgICB9O1xuICAgIC8v0L/QvtC70YPRh9C40YLRjCBpZCDRhNC+0YDQvNGLINGB0YPRidC90L7RgdGC0LhcbiAgICBVc2VyVmFsdWVzTWFuYWdlci5wcm90b3R5cGUuZ2V0Rm9ybUlkID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gXCIjXCIgKyB0aGlzLmdldEVudGl0eU5hbWUoKSArIFwiLWZvcm1cIjtcbiAgICB9O1xuICAgIC8v0L/QvtC70YPRh9C40YLRjCBpZCDQutC90L7Qv9C60Lgg0YHQvtC30LTQsNC90LjRjyDRgdGD0YnQvdC+0YHRgtC4XG4gICAgVXNlclZhbHVlc01hbmFnZXIucHJvdG90eXBlLmdldENyZWF0ZUJ0bklkID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gXCIjY3JlYXRlLVwiICsgdGhpcy5nZXRFbnRpdHlOYW1lKCk7XG4gICAgfTtcbiAgICAvL9C/0L7Qu9GD0YfQuNGC0YwgY2xhc3Mg0LrQvdC+0L/QutC4INGD0LTQsNC70LXQvdC40Y8g0YHRg9GJ0L3QvtGB0YLQuFxuICAgIFVzZXJWYWx1ZXNNYW5hZ2VyLnByb3RvdHlwZS5nZXREZWxldGVCdG5DbGFzcyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIFwiLmRlbGV0ZS1cIiArIHRoaXMuZ2V0RW50aXR5TmFtZSgpO1xuICAgIH07XG4gICAgLy/Qv9C+0LvRg9GH0LjRgtGMIGNsYXNzINC60L3QvtC/0LrQuCDQvtCx0L3QvtCy0LvQtdC90LjRjyDRgdGD0YnQvdC+0YHRgtC4XG4gICAgVXNlclZhbHVlc01hbmFnZXIucHJvdG90eXBlLmdldFVwZGF0ZUJ0bkNsYXNzID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gXCIudXBkYXRlLVwiICsgdGhpcy5nZXRFbnRpdHlOYW1lKCk7XG4gICAgfTtcbiAgICAvL9C/0L7Qu9GD0YfQuNGC0Ywg0LLRi9Cx0YDQsNC90L3Ri9C1INGB0YPRidC90L7RgdGC0Lgg0LjQtyDRhNC+0YDQvNGLXG4gICAgVXNlclZhbHVlc01hbmFnZXIucHJvdG90eXBlLmdldE11bHRpU2VsZWN0ZWRPYmplY3RzID0gZnVuY3Rpb24gKGZvcm1EYXRhKSB7XG4gICAgICAgIHZhciBtdWx0aUlkaWNpZXMgPSBmb3JtRGF0YS5tdWx0aTtcbiAgICAgICAgdmFyIG11bHRpQXJyYXkgPSBbXTtcbiAgICAgICAgaWYgKG11bHRpSWRpY2llcykge1xuICAgICAgICAgICAgZm9yICh2YXIgX2kgPSAwLCBtdWx0aUlkaWNpZXNfMSA9IG11bHRpSWRpY2llczsgX2kgPCBtdWx0aUlkaWNpZXNfMS5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgICAgICAgICB2YXIgaW5kZXggPSBtdWx0aUlkaWNpZXNfMVtfaV07XG4gICAgICAgICAgICAgICAgbXVsdGlBcnJheS5wdXNoKHRoaXMuX211bHRpT2JqZWN0c1tpbmRleF0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBtdWx0aUFycmF5O1xuICAgIH07XG4gICAgLy/QvtCx0L3QvtCy0LjRgtGMINGB0L/QuNGB0L7QuiDRgdGD0YnQvdC+0YHRgtC10LlcbiAgICBVc2VyVmFsdWVzTWFuYWdlci5wcm90b3R5cGUudXBkYXRlUmVzb3VyY2VzTGlzdCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgaWYgKHRoaXMuX211bHRpT2JqZWN0cykge1xuICAgICAgICAgICAgdGhpcy5fbXVsdGlTZWxlY3QuZW1wdHkoKTtcbiAgICAgICAgICAgIHZhciBpID0gMDtcbiAgICAgICAgICAgIGZvciAodmFyIF9pID0gMCwgX2EgPSB0aGlzLl9tdWx0aU9iamVjdHM7IF9pIDwgX2EubGVuZ3RoOyBfaSsrKSB7XG4gICAgICAgICAgICAgICAgdmFyIG9iamVjdCA9IF9hW19pXTtcbiAgICAgICAgICAgICAgICB0aGlzLl9tdWx0aVNlbGVjdC5hcHBlbmQoJzxvcHRpb24gdmFsdWU9XCInICsgaSArICdcIj4nICtcbiAgICAgICAgICAgICAgICAgICAgb2JqZWN0Lm5hbWUgK1xuICAgICAgICAgICAgICAgICAgICAnPC9vcHRpb24+Jyk7XG4gICAgICAgICAgICAgICAgKytpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5fbXVsdGlTZWxlY3QubXVsdGlTZWxlY3QoJ3JlZnJlc2gnKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgLy/Rg9GB0YLQsNC90L7QstC40YLRjCDQstGL0LHRgNCw0L3QvdGL0LUg0YHRg9GJ0L3QvtGB0YLQuCDQvdCwINGE0L7RgNC80LVcbiAgICBVc2VyVmFsdWVzTWFuYWdlci5wcm90b3R5cGUuc2V0TXVsdGlTZWxlY3QgPSBmdW5jdGlvbiAoZW50aXR5KSB7XG4gICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgIGlmICh0aGlzLl9tdWx0aU9iamVjdHMpIHtcbiAgICAgICAgICAgIHZhciBtdWx0aUlkaWNpZXNfMiA9IFtdO1xuICAgICAgICAgICAgZm9yICh2YXIgX2kgPSAwLCBfYSA9IHRoaXMuZ2V0TXVsdGlPYmplY3RzKGVudGl0eSk7IF9pIDwgX2EubGVuZ3RoOyBfaSsrKSB7XG4gICAgICAgICAgICAgICAgdmFyIG11bHRpID0gX2FbX2ldO1xuICAgICAgICAgICAgICAgIG11bHRpSWRpY2llc18yLnB1c2godGhpcy5fbXVsdGlPYmplY3RzLmluZGV4T2YobXVsdGkpLnRvU3RyaW5nKCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgX3RoaXMuX211bHRpU2VsZWN0Lm11bHRpU2VsZWN0KCdzZWxlY3QnLCBtdWx0aUlkaWNpZXNfMik7XG4gICAgICAgICAgICB9LCAwKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgLy/Qv9C+0LrQsNC30LDRgtGMINGE0L7RgNC80YMg0YDQtdC00LDQutGC0LjRgNC+0LLQsNC90LjRj1xuICAgIFVzZXJWYWx1ZXNNYW5hZ2VyLnByb3RvdHlwZS5vcGVuRm9ybSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdGhpcy51cGRhdGVSZXNvdXJjZXNMaXN0KCk7XG4gICAgICAgIHRoaXMuX21vZGFsLmRpYWxvZygnb3BlbicpO1xuICAgICAgICB0aGlzLl9tb2RhbC5kaWFsb2coJ29wdGlvbicsICdwb3NpdGlvbicsIHsgbXk6IFwidG9wIHRvcFwiLCBhdDogXCJ0b3AgdG9wXCIsIG9mOiB3aW5kb3cgfSk7XG4gICAgfTtcbiAgICAvL9C30LDQutGA0YvRgtGMINGE0L7RgNC80YMg0YDQtdC00LDQutGC0LjRgNC+0LLQsNC90LjRj1xuICAgIFVzZXJWYWx1ZXNNYW5hZ2VyLnByb3RvdHlwZS5jbG9zZUZvcm0gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHRoaXMuX21vZGFsLmRpYWxvZygnY2xvc2UnKTtcbiAgICB9O1xuICAgIC8v0L/QvtC70YPRh9C40YLRjCDQtNCw0L3QvdGL0LUg0YTQvtGA0LzRiyDRgNC10LTQsNC60YLQuNGA0L7QstCw0L3QuNGPXG4gICAgVXNlclZhbHVlc01hbmFnZXIucHJvdG90eXBlLmZvcm1EYXRhID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fZm9ybS5zZXJpYWxpemVBcnJheSgpLnJlZHVjZShmdW5jdGlvbiAob2JqLCBpdGVtKSB7XG4gICAgICAgICAgICBpZiAob2JqW2l0ZW0ubmFtZV0pIHtcbiAgICAgICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShvYmpbaXRlbS5uYW1lXSkpIHtcbiAgICAgICAgICAgICAgICAgICAgb2JqW2l0ZW0ubmFtZV0ucHVzaChpdGVtLnZhbHVlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIG9ialtpdGVtLm5hbWVdID0gW29ialtpdGVtLm5hbWVdLCBpdGVtLnZhbHVlXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBvYmpbaXRlbS5uYW1lXSA9IGl0ZW0udmFsdWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gb2JqO1xuICAgICAgICB9LCB7fSk7XG4gICAgfTtcbiAgICAvL9GB0L7RhdGA0LDQvdC40YLRjCDRhNC+0YDQvNGDINGA0LXQtNCw0LrRgtC40YDQvtCy0LDQvdC40Y8g0LIg0YHRg9GJ0L3QvtGB0YLRjFxuICAgIFVzZXJWYWx1ZXNNYW5hZ2VyLnByb3RvdHlwZS5zYXZlRm9ybSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIGRhdGEgPSB0aGlzLmZvcm1EYXRhKCk7XG4gICAgICAgIHZhciBlbnRpdHkgPSB0aGlzLmNyZWF0ZUVudGl0eShkYXRhKTtcbiAgICAgICAgaWYgKHRoaXMuX3VwZGF0ZUluZGV4IDwgMCkge1xuICAgICAgICAgICAgdGhpcy5fZW50aXRpZXMucHVzaChlbnRpdHkpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5fZW50aXRpZXNbdGhpcy5fdXBkYXRlSW5kZXhdID0gZW50aXR5O1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuX3VwZGF0ZUluZGV4ID0gLTE7XG4gICAgICAgIHRoaXMucmVuZGVyTGlzdCgpO1xuICAgIH07XG4gICAgLy/Rg9C00LDQu9C40YLRjCDRgdGD0YnQvdC+0YHRgtGMXG4gICAgVXNlclZhbHVlc01hbmFnZXIucHJvdG90eXBlLmRlbGV0ZUVudGl0eSA9IGZ1bmN0aW9uIChpbmRleCkge1xuICAgICAgICB0aGlzLl9lbnRpdGllcy5zcGxpY2UoaW5kZXgsIDEpO1xuICAgICAgICB0aGlzLnJlbmRlckxpc3QoKTtcbiAgICB9O1xuICAgIC8v0L7QsdC90L7QstC40YLRjCDRgdGD0YnQvdC+0YHRgtGMXG4gICAgVXNlclZhbHVlc01hbmFnZXIucHJvdG90eXBlLnVwZGF0ZUVudGl0eSA9IGZ1bmN0aW9uIChpbmRleCkge1xuICAgICAgICB0aGlzLl91cGRhdGVJbmRleCA9IGluZGV4O1xuICAgICAgICB2YXIgdXBkYXRpbmdFbnRpdHkgPSB0aGlzLl9lbnRpdGllc1tpbmRleF07XG4gICAgICAgIHRoaXMudXBkYXRlUmVzb3VyY2VzTGlzdCgpO1xuICAgICAgICB0aGlzLnNldEZvcm1WYWx1ZXModXBkYXRpbmdFbnRpdHkpO1xuICAgICAgICB0aGlzLnNldE11bHRpU2VsZWN0KHVwZGF0aW5nRW50aXR5KTtcbiAgICAgICAgdGhpcy5vcGVuRm9ybSgpO1xuICAgIH07XG4gICAgLy/QvtGC0L7QsdGA0LDQt9C40YLRjCDRgdC/0LjRgdC+0Log0YHRg9GJ0L3QvtGB0YLQtdC5XG4gICAgVXNlclZhbHVlc01hbmFnZXIucHJvdG90eXBlLnJlbmRlckxpc3QgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBjb250ZXh0ID0ge307XG4gICAgICAgIGNvbnRleHRbdGhpcy5nZXRFbnRpdHlOYW1lKCldID0gdGhpcy5fZW50aXRpZXM7XG4gICAgICAgIHRoaXMuX2xpc3QuaHRtbCh0aGlzLl9saXN0VGVtcGxhdGUoY29udGV4dCkpO1xuICAgIH07XG4gICAgcmV0dXJuIFVzZXJWYWx1ZXNNYW5hZ2VyO1xufSgpKTtcbmV4cG9ydHMuVXNlclZhbHVlc01hbmFnZXIgPSBVc2VyVmFsdWVzTWFuYWdlcjtcbiIsIlwidXNlIHN0cmljdFwiO1xudmFyIENlbGxfMSA9IHJlcXVpcmUoXCIuL0NlbGxcIik7XG52YXIgYXNFdmVudGVkID0gcmVxdWlyZSgnLi9hc2V2ZW50ZWQubWluLmpzJyk7XG52YXIgQmFkRmFjdG9yXzEgPSByZXF1aXJlKFwiLi9CYWRGYWN0b3JcIik7XG52YXIgUmVzb3VyY2VfMSA9IHJlcXVpcmUoXCIuL1Jlc291cmNlXCIpO1xuLy/QodC60LvQsNC0XG52YXIgV2FyZWhvdXNlID0gKGZ1bmN0aW9uICgpIHtcbiAgICBmdW5jdGlvbiBXYXJlaG91c2UocmVzb3VyY2VzLCBiYWRGYWN0b3JzKSB7XG4gICAgICAgIC8v0JzQsNC60YHQuNC80LDQu9GM0L3QvtC1INC60L7Qu9C40YfQtdGB0YLQstC+INC80LXRgdGCINC90LAg0YHQutC70LDQtNC1XG4gICAgICAgIHRoaXMuX2NhcGFjaXR5ID0gMTA7XG4gICAgICAgIC8v0JfQsNC90Y/RgtGL0LUg0LzQtdGB0YLQsCDQvdCwINGB0LrQu9Cw0LTQtVxuICAgICAgICB0aGlzLl9jZWxscyA9IFtdO1xuICAgICAgICB0aGlzLl9yZXNvdXJjZXMgPSByZXNvdXJjZXM7XG4gICAgICAgIHRoaXMuX2JhZEZhY3RvcnMgPSBiYWRGYWN0b3JzO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRoaXMuX2NhcGFjaXR5OyArK2kpIHtcbiAgICAgICAgICAgIHRoaXMuX2NlbGxzLnB1c2gobmV3IENlbGxfMS5DZWxsKG51bGwsIDApKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICAvL9CS0YvRh9C40YHQu9GP0LXRgiDQsNGA0LXQvdC00L3Rg9GOINC/0LvQsNGC0YMg0LfQsCDRhdGA0LDQvdC10L3QuNC1INGA0LXRgdGD0YDRgdCwXG4gICAgV2FyZWhvdXNlLnByb3RvdHlwZS5jZWxsUmVudCA9IGZ1bmN0aW9uIChjZWxsKSB7XG4gICAgICAgIHJldHVybiBNYXRoLnJvdW5kKGNlbGwucmVzb3VyY2UuZGVzY3JpcHRpb24ucmVudCAqIGNlbGwuc3RvcmVEYXlzICpcbiAgICAgICAgICAgIGNlbGwucmVzb3VyY2UucXVhbGl0eSAvIGNlbGwucmVzb3VyY2UuZGVzY3JpcHRpb24ucXVhbGl0eSk7XG4gICAgfTtcbiAgICAvL9CS0YvRh9C40YHQu9GP0LXRgiDRiNGC0YDQsNGEINC30LAg0L/QvtC70L3Rg9GOINC/0L7RgNGH0YMg0YDQtdGB0YPRgNGB0LBcbiAgICBXYXJlaG91c2UucHJvdG90eXBlLmNlbGxQZW5hbHR5ID0gZnVuY3Rpb24gKGNlbGwpIHtcbiAgICAgICAgcmV0dXJuIE1hdGgucm91bmQoY2VsbC5yZXNvdXJjZS5kZXNjcmlwdGlvbi5yZW50ICogY2VsbC5zdG9yZURheXMgLyAyKTtcbiAgICB9O1xuICAgIC8v0L7QsdGA0LDQsdC+0YLQutCwINGB0YPRidC10YHRgtCy0YPRjtGJ0LjRhSDQvNC10YHRglxuICAgIFdhcmVob3VzZS5wcm90b3R5cGUucHJvY2Vzc0NlbGxzID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgY2VsbHNUb1JlbW92ZSA9IFtdO1xuICAgICAgICB2YXIgaSA9IDA7XG4gICAgICAgIGZvciAodmFyIF9pID0gMCwgX2EgPSB0aGlzLl9jZWxsczsgX2kgPCBfYS5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgICAgIHZhciBjZWxsID0gX2FbX2ldO1xuICAgICAgICAgICAgaWYgKGNlbGwucmVzb3VyY2UgIT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICBpZiAoY2VsbC5iYWRGYWN0b3IpIHtcbiAgICAgICAgICAgICAgICAgICAgY2VsbC5iYWRGYWN0b3IuYWZmZWN0KGNlbGwucmVzb3VyY2UpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmVtaXQoJ2NlbGwtcmVzb3VyY2UtZGFtYWdlZCcsIGNlbGwpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoY2VsbC5yZXNvdXJjZS5xdWFsaXR5IDw9IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNlbGxzVG9SZW1vdmUucHVzaChpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZW1pdCgnY2VsbC1yZXNvdXJjZS1kZXN0cm95ZWQnLCBjZWxsLCB0aGlzLmNlbGxQZW5hbHR5KGNlbGwpLCBpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNlbGwucmVzdFN0b3JlRGF5cyAtPSAxO1xuICAgICAgICAgICAgICAgIGlmIChjZWxsLnJlc3RTdG9yZURheXMgPD0gMCkge1xuICAgICAgICAgICAgICAgICAgICBjZWxsc1RvUmVtb3ZlLnB1c2goaSk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZW1pdCgnY2VsbC1yZW50JywgY2VsbCwgdGhpcy5jZWxsUmVudChjZWxsKSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgKytpO1xuICAgICAgICB9XG4gICAgICAgIGZvciAodmFyIF9iID0gMCwgY2VsbHNUb1JlbW92ZV8xID0gY2VsbHNUb1JlbW92ZTsgX2IgPCBjZWxsc1RvUmVtb3ZlXzEubGVuZ3RoOyBfYisrKSB7XG4gICAgICAgICAgICB2YXIgaWR4ID0gY2VsbHNUb1JlbW92ZV8xW19iXTtcbiAgICAgICAgICAgIHRoaXMuX2NlbGxzW2lkeF0gPSBuZXcgQ2VsbF8xLkNlbGwobnVsbCwgMCk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIC8v0YDQsNGB0L/RgNC+0YHRgtGA0LDQvdC10L3QuNC1INC/0LvQvtGF0LjRhSDRhNCw0LrRgtC+0YDQvtCyXG4gICAgV2FyZWhvdXNlLnByb3RvdHlwZS5zcHJlYWRCYWRGYWN0b3JzID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgaSA9IDA7XG4gICAgICAgIGZvciAodmFyIF9pID0gMCwgX2EgPSB0aGlzLl9jZWxsczsgX2kgPCBfYS5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgICAgIHZhciBjZWxsID0gX2FbX2ldO1xuICAgICAgICAgICAgaWYgKGNlbGwucmVzb3VyY2UgIT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBfYiA9IDAsIF9jID0gdGhpcy5fYmFkRmFjdG9yczsgX2IgPCBfYy5sZW5ndGg7IF9iKyspIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGZhY3RvciA9IF9jW19iXTtcbiAgICAgICAgICAgICAgICAgICAgLy/QstC10YDQvtGP0YLQvdC+0YHRgtGMINC/0L7Rj9Cy0LjRgtGM0YHRj1xuICAgICAgICAgICAgICAgICAgICBpZiAoIWNlbGwuYmFkRmFjdG9yICYmXG4gICAgICAgICAgICAgICAgICAgICAgICBmYWN0b3IuY2FuQWZmZWN0VG8oY2VsbC5yZXNvdXJjZSkgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgIE1hdGgucmFuZG9tKCkgPCAwLjIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNlbGwuYmFkRmFjdG9yID0gbmV3IEJhZEZhY3Rvcl8xLkJhZEZhY3RvcihmYWN0b3IpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5lbWl0KCdiYWQtZmFjdG9yLXNwcmVhZCcsIGNlbGwsIGkpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgKytpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICAvL9C/0L7Qu9GD0YfQuNGC0Ywg0LjQvdC00LXQutGBINC/0YPRgdGC0L7Qs9C+INC80LXRgdGC0LBcbiAgICBXYXJlaG91c2UucHJvdG90eXBlLmdldEVtcHR5SW5kZXggPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBpID0gMDtcbiAgICAgICAgZm9yICh2YXIgX2kgPSAwLCBfYSA9IHRoaXMuX2NlbGxzOyBfaSA8IF9hLmxlbmd0aDsgX2krKykge1xuICAgICAgICAgICAgdmFyIGNlbGwgPSBfYVtfaV07XG4gICAgICAgICAgICBpZiAoY2VsbC5yZXNvdXJjZSA9PT0gbnVsbCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgKytpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICAvL9C/0L7RgdGC0YPQv9C70LXQvdC40LUg0L3QvtCy0YvRhSDRgNC10YHRg9GA0YHQvtCyXG4gICAgV2FyZWhvdXNlLnByb3RvdHlwZS5wcm9jZXNzTmV3Q2VsbHMgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciByZXN0Q2VsbENvdW50ID0gdGhpcy5fY2FwYWNpdHkgLSB0aGlzLmJ1c3lDZWxscztcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCByZXN0Q2VsbENvdW50OyArK2kpIHtcbiAgICAgICAgICAgIC8v0LLQtdGA0L7Rj9GC0L3QvtGB0YLRjCDQvdC+0LLQvtCz0L4g0LfQsNC60LDQt9CwXG4gICAgICAgICAgICBpZiAoTWF0aC5yYW5kb20oKSA8IDAuMTUpIHtcbiAgICAgICAgICAgICAgICB2YXIgcmFuZG9tUmVzb3VyY2UgPSB0aGlzLl9yZXNvdXJjZXNbTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogdGhpcy5fcmVzb3VyY2VzLmxlbmd0aCldO1xuICAgICAgICAgICAgICAgIHZhciBzdG9yZURheXMgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAyMCkgKyAxO1xuICAgICAgICAgICAgICAgIHZhciBjZWxsID0gbmV3IENlbGxfMS5DZWxsKG5ldyBSZXNvdXJjZV8xLlJlc291cmNlKHJhbmRvbVJlc291cmNlKSwgc3RvcmVEYXlzKTtcbiAgICAgICAgICAgICAgICB0aGlzLl9jZWxsc1t0aGlzLmdldEVtcHR5SW5kZXgoKV0gPSBjZWxsO1xuICAgICAgICAgICAgICAgIHRoaXMuZW1pdCgnbmV3LWNlbGwnLCBjZWxsKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH07XG4gICAgLy/QodC80L7QtNC10LvQuNGA0L7QstCw0YLRjCDRgdC+0LHRi9GC0LjRjywg0L/RgNC+0YjQtdC00YjQuNC1INC30LAg0L7QtNC40L0g0LTQtdC90YxcbiAgICBXYXJlaG91c2UucHJvdG90eXBlLnByb2Nlc3NEYXkgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHRoaXMucHJvY2Vzc0NlbGxzKCk7XG4gICAgICAgIHRoaXMuc3ByZWFkQmFkRmFjdG9ycygpO1xuICAgICAgICB0aGlzLnByb2Nlc3NOZXdDZWxscygpO1xuICAgIH07XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KFdhcmVob3VzZS5wcm90b3R5cGUsIFwiY2VsbHNcIiwge1xuICAgICAgICAvL9CS0L7Qt9Cy0YDQsNGJ0LDQtdGCINC80LDRgdGB0LjQsiDQt9Cw0L3Rj9GC0YvRhSDRj9GH0LXQtdC6INGB0LrQu9Cw0LTQsFxuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9jZWxscztcbiAgICAgICAgfSxcbiAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSk7XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KFdhcmVob3VzZS5wcm90b3R5cGUsIFwiY2VsbENvc3RcIiwge1xuICAgICAgICAvL9CS0L7Qt9Cy0YDQsNGJ0LDQtdGCINGB0YLQvtC40LzQvtGB0YLRjCDRg9Cy0LXQu9C40YfQtdC90LjRjyDQstC80LXRgdGC0LjQvNC+0YHRgtC4INGB0LrQu9Cw0LTQsCDQvdCwINC+0LTQvdC+INC80LXRgdGC0L5cbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fY2FwYWNpdHkgKiAzMDA7XG4gICAgICAgIH0sXG4gICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0pO1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShXYXJlaG91c2UucHJvdG90eXBlLCBcImNhcGFjaXR5XCIsIHtcbiAgICAgICAgLy/QktC+0LfQstGA0LDRidCw0LXRgiDQvNCw0LrRgdC40LzQsNC70YzQvdC+0LUg0LrQvtC70LjRh9C10YHRgtCy0L4g0LzQtdGB0YIg0L3QsCDRgdC60LvQsNC00LVcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fY2FwYWNpdHk7XG4gICAgICAgIH0sXG4gICAgICAgIC8v0KPRgdGC0LDQvdCw0LLQu9C40LLQsNC10YIg0LzQsNC60YHQuNC80LDQu9GM0L3QvtC1INC60L7Qu9C40YfQtdGB0YLQstC+INC80LXRgdGCINC90LAg0YHQutC70LDQtNC1XG4gICAgICAgIHNldDogZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5fY2FwYWNpdHkgPCB2YWx1ZSkge1xuICAgICAgICAgICAgICAgIHZhciBkaWZmID0gdmFsdWUgLSB0aGlzLl9jYXBhY2l0eTtcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGRpZmY7ICsraSkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLl9jZWxscy5wdXNoKG5ldyBDZWxsXzEuQ2VsbChudWxsLCAwKSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5fY2FwYWNpdHkgPSB2YWx1ZTtcbiAgICAgICAgfSxcbiAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSk7XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KFdhcmVob3VzZS5wcm90b3R5cGUsIFwiYnVzeUNlbGxzXCIsIHtcbiAgICAgICAgLy/QktC+0LfQstGA0LDRidCw0LXRgiDQutC+0LvQuNGH0LXRgdGC0LLQviDQt9Cw0L3Rj9GC0YvRhSDQvNC10YHRgiDQvdCwINGB0LrQu9Cw0LTQtVxuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9jZWxscy5maWx0ZXIoZnVuY3Rpb24gKGNlbGwpIHsgcmV0dXJuIGNlbGwucmVzb3VyY2UgIT0gbnVsbDsgfSkubGVuZ3RoO1xuICAgICAgICB9LFxuICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9KTtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoV2FyZWhvdXNlLnByb3RvdHlwZSwgXCJjb3JydXB0ZWRDZWxsc1wiLCB7XG4gICAgICAgIC8v0JLQvtC30LLRgNCw0YnQsNC10YIg0L3QvtC80LXRgNCwINC30LDQvdGP0YLRi9GFINC80LXRgdGCLCDQsiDQutC+0YLQvtGA0YvRhSDQtdGB0YLRjCDQv9C70L7RhdC+0Lkg0YTQsNC60YLQvtGAXG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIGkgPSAwO1xuICAgICAgICAgICAgdmFyIGNvcnJ1cHRlZCA9IFtdO1xuICAgICAgICAgICAgZm9yICh2YXIgX2kgPSAwLCBfYSA9IHRoaXMuY2VsbHM7IF9pIDwgX2EubGVuZ3RoOyBfaSsrKSB7XG4gICAgICAgICAgICAgICAgdmFyIGNlbGwgPSBfYVtfaV07XG4gICAgICAgICAgICAgICAgaWYgKGNlbGwuYmFkRmFjdG9yKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvcnJ1cHRlZC5wdXNoKGkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICArK2k7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gY29ycnVwdGVkO1xuICAgICAgICB9LFxuICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9KTtcbiAgICByZXR1cm4gV2FyZWhvdXNlO1xufSgpKTtcbmV4cG9ydHMuV2FyZWhvdXNlID0gV2FyZWhvdXNlO1xuLy9ub2luc3BlY3Rpb24gVHlwZVNjcmlwdFVucmVzb2x2ZWRGdW5jdGlvblxuYXNFdmVudGVkLmNhbGwoV2FyZWhvdXNlLnByb3RvdHlwZSk7XG4iLCIvKiEgYXNFdmVudGVkIHYwLjQuMyBnaXRodWIuY29tL21rdWtsaXMvYXNFdmVudGVkIHwgRHVhbCBsaWNlbnNlZCB1bmRlciB0aGUgTUlUIG9yIEdQTCBWZXJzaW9uIDIgbGljZW5zZXMuICovXG4oZnVuY3Rpb24gKGYsIGcsIGIpIHsgXCJ1bmRlZmluZWRcIiAhPT0gdHlwZW9mIG1vZHVsZSA/IG1vZHVsZS5leHBvcnRzID0gYigpIDogXCJ1bmRlZmluZWRcIiAhPT0gdHlwZW9mIHJlcXVpcmUgJiYgXCJvYmplY3RcIiA9PT0gdHlwZW9mIGRlZmluZS5hbWQgPyBkZWZpbmUoYikgOiBnW2ZdID0gYigpOyB9KShcImFzRXZlbnRlZFwiLCB0aGlzLCBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgZnVuY3Rpb24gZihoLCBlKSB7IHZhciBhLCBkLCBjID0gdGhpcy5ldmVudHMgPSB0aGlzLmV2ZW50cyB8fCB7fSwgYiA9IGguc3BsaXQoL1xccysvKSwgayA9IGIubGVuZ3RoOyBmb3IgKGEgPSAwOyBhIDwgazsgYSsrKVxuICAgICAgICAgICAgY1tkID0gYlthXV0gPSBjW2RdIHx8IFtdLCBjW2RdLnB1c2goZSk7IHJldHVybiB0aGlzOyB9XG4gICAgICAgIGZ1bmN0aW9uIGcoaCwgZSkgeyB2YXIgYSA9IGZ1bmN0aW9uICgpIHsgZS5hcHBseSh0aGlzLCBuLmNhbGwoYXJndW1lbnRzKSk7IHRoaXMudW5iaW5kKGgsIGEpOyB9OyB0aGlzLmJpbmQoaCwgYSk7IHJldHVybiB0aGlzOyB9XG4gICAgICAgIGZ1bmN0aW9uIGIoaCwgZSkge1xuICAgICAgICAgICAgdmFyIGEsIGQsIGMsIGIsIGssIG0gPSB0aGlzLmV2ZW50cztcbiAgICAgICAgICAgIGlmIChtKSB7XG4gICAgICAgICAgICAgICAgayA9IGguc3BsaXQoL1xccysvKTtcbiAgICAgICAgICAgICAgICBkID0gMDtcbiAgICAgICAgICAgICAgICBmb3IgKGIgPSBrLmxlbmd0aDsgZCA8IGI7IGQrKylcbiAgICAgICAgICAgICAgICAgICAgaWYgKCExICE9PSAoYSA9IGtbZF0pIGluIG0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGE6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYyA9IG1bYV07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBmID0gZSwgbCA9IHZvaWQgMCwgZyA9IHZvaWQgMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHAgJiYgYy5pbmRleE9mID09PSBwKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYyA9IGMuaW5kZXhPZihmKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoZyA9IGMubGVuZ3RoOyBsIDwgZzsgbCsrKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjW2xdID09PSBmKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGMgPSBsO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhayBhO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGMgPSAtMTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIC0xICE9PSBjICYmIG1bYV0uc3BsaWNlKGMsIDEpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZnVuY3Rpb24gcihiKSB7IHZhciBlLCBhLCBkID0gdGhpcy5ldmVudHM7IGlmIChkICYmICExICE9PSBiIGluIGQpIHtcbiAgICAgICAgICAgIGUgPSBuLmNhbGwoYXJndW1lbnRzLCAxKTtcbiAgICAgICAgICAgIGZvciAoYSA9IGRbYl0ubGVuZ3RoIC0gMTsgMCA8PSBhOyBhLS0pXG4gICAgICAgICAgICAgICAgZFtiXVthXS5hcHBseSh0aGlzLCBlKTtcbiAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9IH1cbiAgICAgICAgdmFyIHEgPSBBcnJheS5wcm90b3R5cGUsIHAgPSBxLmluZGV4T2YsIG4gPSBxLnNsaWNlO1xuICAgICAgICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdGhpcy5iaW5kID0gdGhpcy5vbiA9IGY7XG4gICAgICAgICAgICB0aGlzLnVuYmluZCA9IHRoaXMub2ZmID0gdGhpcy5yZW1vdmVMaXN0ZW5lciA9IGI7XG4gICAgICAgICAgICB0aGlzLnRyaWdnZXIgPSB0aGlzLmVtaXQgPSByO1xuICAgICAgICAgICAgdGhpcy5vbmUgPSB0aGlzLm9uY2UgPSBnO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH07XG4gICAgfSgpO1xufSk7XG4iLCJcInVzZSBzdHJpY3RcIjtcbnZhciBHYW1lTWFuYWdlcl8xID0gcmVxdWlyZShcIi4vR2FtZU1hbmFnZXJcIik7XG4kKGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgXyA9IG5ldyBHYW1lTWFuYWdlcl8xLkdhbWVNYW5hZ2VyO1xufSk7XG4iLCJcInVzZSBzdHJpY3RcIjtcbi8v0LLRi9Cx0L7RgCDQt9C90LDRh9C10L3QuNC5INC80LDRgdGB0LjQstCwINC/0L4g0LjQvdC00LXQutGB0LDQvFxuZnVuY3Rpb24gc2VsZWN0SW5kZXhlcyhhcnIsIGluZGV4ZXMpIHtcbiAgICB2YXIgcmVzID0gW107XG4gICAgZm9yICh2YXIgX2kgPSAwLCBpbmRleGVzXzEgPSBpbmRleGVzOyBfaSA8IGluZGV4ZXNfMS5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgdmFyIGkgPSBpbmRleGVzXzFbX2ldO1xuICAgICAgICByZXMucHVzaChhcnJbaV0pO1xuICAgIH1cbiAgICByZXR1cm4gcmVzO1xufVxuZXhwb3J0cy5zZWxlY3RJbmRleGVzID0gc2VsZWN0SW5kZXhlcztcbiJdfQ==
